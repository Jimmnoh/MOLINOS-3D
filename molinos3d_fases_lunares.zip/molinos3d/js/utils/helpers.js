function limitar(v, mn, mx) { return Math.max(mn, Math.min(mx, v)); }
function mezclar(a, b, t) { return a + (b - a) * t; }

function suave(a, b, x) {
    const t = limitar((x - a) / (b - a), 0, 1);
    return t * t * (3 - 2 * t);
}

function mezclarVec(a, b, t) {
    return [mezclar(a[0], b[0], t), mezclar(a[1], b[1], t), mezclar(a[2], b[2], t)];
}

// Generador pseudoaleatorio con semilla (la aldea es siempre la misma).
function crearRandom(semilla) {
    let s = semilla >>> 0;
    return function () {
        s += 0x6D2B79F5;
        let t = s;
        t = Math.imul(t ^ (t >>> 15), t | 1);
        t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
        return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
}



// Ruido de valor 2D para colinas y lecho del río.
function hash2(x, y) {
    const h = Math.sin(x * 127.1 + y * 311.7) * 43758.5453;
    return h - Math.floor(h);
}

function ruido2(x, y) {
    const ix = Math.floor(x), iy = Math.floor(y);
    let fx = x - ix, fy = y - iy;
    fx = fx * fx * (3 - 2 * fx);
    fy = fy * fy * (3 - 2 * fy);
    const a = hash2(ix, iy), b = hash2(ix + 1, iy);
    const c = hash2(ix, iy + 1), d = hash2(ix + 1, iy + 1);
    return mezclar(mezclar(a, b, fx), mezclar(c, d, fx), fy);
}

function fbm2(x, y) {
    let suma = 0, amp = 0.5;
    for (let i = 0; i < 4; i++) {
        suma += amp * ruido2(x, y);
        x = x * 2.03 + 17.0;
        y = y * 2.03 + 9.0;
        amp *= 0.5;
    }
    return suma;
}


export { limitar, mezclar, suave, mezclarVec, crearRandom, hash2, ruido2, fbm2 };
