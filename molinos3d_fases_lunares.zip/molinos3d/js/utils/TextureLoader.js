export class TextureLoader {
constructor(gl) {
const extAniso=gl.getExtension("EXT_texture_filter_anisotropic");
this.createColor = function(r, g, b) {

    const textura = gl.createTexture();
    gl.bindTexture(gl.TEXTURE_2D, textura);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, 1, 1, 0, gl.RGBA, gl.UNSIGNED_BYTE,
        new Uint8Array([r, g, b, 255]));
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);

    return textura;
}

// Empieza con un color liso y se reemplaza cuando la imagen termina de cargar.
this.load = function(url, colorRespaldo = [150, 150, 150]) {

    const textura = this.createColor(colorRespaldo[0], colorRespaldo[1], colorRespaldo[2]);
    const imagen = new Image();

    imagen.onload = () => {

        gl.bindTexture(gl.TEXTURE_2D, textura);
        gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, imagen);
        gl.generateMipmap(gl.TEXTURE_2D);

        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR_MIPMAP_LINEAR);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.REPEAT);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.REPEAT);

        if (extAniso) {
            gl.texParameterf(gl.TEXTURE_2D, extAniso.TEXTURE_MAX_ANISOTROPY_EXT, 8);
        }
    };

    imagen.onerror = () => {
        console.warn("No se pudo cargar " + url + ". Usa un servidor local (http), no file://.");
    };

    imagen.src = url;

    return textura;
}


}
}
