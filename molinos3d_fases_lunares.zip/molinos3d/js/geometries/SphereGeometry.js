import { Geometry } from '../core/Geometry.js';
import { crearEsfera } from './generators.js';
export class SphereGeometry extends Geometry {
    constructor(radius=1, latitudes=20, longitudes=28) {
        super(crearEsfera(radius,latitudes,longitudes));
    }
}
