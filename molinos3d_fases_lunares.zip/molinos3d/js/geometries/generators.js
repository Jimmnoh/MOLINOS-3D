import { identidad4, multiplicarMat4, traslacion, escala, rotacionX, rotacionY, rotacionZ, componer, restar, normalizar, cruz, lookAt, perspectiva, ortografica } from "../math/Matrix4.js";
import { limitar, mezclar, suave, mezclarVec, crearRandom, hash2, ruido2, fbm2 } from "../utils/helpers.js";
import { NIVEL_AGUA, NIVEL_ORILLA, MEDIO_TERRENO, ANCHO_AGUA, configViento, configAgua, DIST_MOLINO_AGUA, rioX, rioDX, tangenteRio, distanciaRio, alturaBase, alturaCimas, alturaTerreno } from "../scene/terrain.js";
function crearCubo() {

    // 6 caras, cada una con 4 vértices propios (normales planas).
    const caras = [
        { n: [0,0,1],  u: [1,0,0], v: [0,1,0] },
        { n: [0,0,-1], u: [-1,0,0], v: [0,1,0] },
        { n: [1,0,0],  u: [0,0,-1], v: [0,1,0] },
        { n: [-1,0,0], u: [0,0,1], v: [0,1,0] },
        { n: [0,1,0],  u: [1,0,0], v: [0,0,-1] },
        { n: [0,-1,0], u: [1,0,0], v: [0,0,1] }
    ];

    const vertices = [];
    const indices = [];

    caras.forEach((cara, i) => {
        const esquinas = [[-1,-1],[1,-1],[1,1],[-1,1]];
        esquinas.forEach(([a, b]) => {
            vertices.push(
                0.5 * (cara.n[0] + a * cara.u[0] + b * cara.v[0]),
                0.5 * (cara.n[1] + a * cara.u[1] + b * cara.v[1]),
                0.5 * (cara.n[2] + a * cara.u[2] + b * cara.v[2]),
                cara.n[0], cara.n[1], cara.n[2],
                (a + 1) / 2, (b + 1) / 2
            );
        });
        const o = i * 4;
        indices.push(o, o + 1, o + 2, o, o + 2, o + 3);
    });

    return { vertices: new Float32Array(vertices), indices: new Uint16Array(indices) };
}

function crearEsfera(radio, latitudes, longitudes) {

    const vertices = [];
    const indices = [];

    for (let lat = 0; lat <= latitudes; lat++) {
        const v = lat / latitudes;
        const phi = v * Math.PI;

        for (let lon = 0; lon <= longitudes; lon++) {
            const u = lon / longitudes;
            const theta = u * Math.PI * 2.0;

            const nx = Math.sin(phi) * Math.cos(theta);
            const ny = Math.cos(phi);
            const nz = Math.sin(phi) * Math.sin(theta);

            vertices.push(radio * nx, radio * ny, radio * nz, nx, ny, nz, u, 1.0 - v);
        }
    }

    const columnas = longitudes + 1;

    for (let lat = 0; lat < latitudes; lat++) {
        for (let lon = 0; lon < longitudes; lon++) {
            const a = lat * columnas + lon;
            const b = a + columnas;
            indices.push(a, a + 1, b, b, a + 1, b + 1);
        }
    }

    return { vertices: new Float32Array(vertices), indices: new Uint16Array(indices) };
}

// Cilindro troncocónico: radioInf abajo, radioSup arriba.
// Con radioSup = 0 se obtiene un cono. Base en y=0 (o centrado si centrado=true).
function crearCilindro(radioSup, radioInf, altura, segmentos, centrado = false) {

    const vertices = [];
    const indices = [];
    const y0 = centrado ? -altura / 2 : 0;
    const pendiente = (radioInf - radioSup) / altura;

    // Pared lateral
    for (let i = 0; i <= segmentos; i++) {
        const u = i / segmentos;
        const a = u * Math.PI * 2;
        const c = Math.cos(a), s = Math.sin(a);
        const n = normalizar([c, pendiente, s]);

        vertices.push(radioInf * c, y0, radioInf * s, n[0], n[1], n[2], u, 0);
        vertices.push(radioSup * c, y0 + altura, radioSup * s, n[0], n[1], n[2], u, 1);
    }

    for (let i = 0; i < segmentos; i++) {
        const a = i * 2;
        indices.push(a, a + 1, a + 2, a + 1, a + 3, a + 2);
    }

    // Tapas (solo si el radio es mayor que cero)
    function tapa(radio, y, ny) {
        const centro = vertices.length / 8;
        vertices.push(0, y, 0, 0, ny, 0, 0.5, 0.5);
        for (let i = 0; i <= segmentos; i++) {
            const a = (i / segmentos) * Math.PI * 2;
            vertices.push(radio * Math.cos(a), y, radio * Math.sin(a), 0, ny, 0,
                0.5 + 0.5 * Math.cos(a), 0.5 + 0.5 * Math.sin(a));
        }
        for (let i = 0; i < segmentos; i++) {
            if (ny > 0) indices.push(centro, centro + i + 2, centro + i + 1);
            else indices.push(centro, centro + i + 1, centro + i + 2);
        }
    }

    if (radioSup > 0.0001) tapa(radioSup, y0 + altura, 1);
    if (radioInf > 0.0001) tapa(radioInf, y0, -1);

    return { vertices: new Float32Array(vertices), indices: new Uint16Array(indices) };
}

// Toro (anillo) alrededor del eje Y: se usa para los aros de la rueda.
function crearToro(radioMayor, radioTubo, segMayor, segTubo) {

    const vertices = [];
    const indices = [];

    for (let i = 0; i <= segMayor; i++) {
        const u = i / segMayor;
        const a = u * Math.PI * 2;
        const ca = Math.cos(a), sa = Math.sin(a);

        for (let j = 0; j <= segTubo; j++) {
            const v = j / segTubo;
            const b = v * Math.PI * 2;
            const cb = Math.cos(b), sb = Math.sin(b);

            vertices.push(
                (radioMayor + radioTubo * cb) * ca,
                radioTubo * sb,
                (radioMayor + radioTubo * cb) * sa,
                cb * ca, sb, cb * sa,
                u * 8, v
            );
        }
    }

    const col = segTubo + 1;

    for (let i = 0; i < segMayor; i++) {
        for (let j = 0; j < segTubo; j++) {
            const a = i * col + j;
            const b = a + col;
            indices.push(a, a + 1, b, b, a + 1, b + 1);
        }
    }

    return { vertices: new Float32Array(vertices), indices: new Uint16Array(indices) };
}

// Prisma triangular (techo a dos aguas). Ancho en X, largo en Z,
// cumbrera a lo largo de Z. Base en y=0, cumbrera en y=alto.
function crearTecho(ancho, largo, alto) {

    const hx = ancho / 2, hz = largo / 2;
    const vertices = [];
    const indices = [];
    const pend = normalizar([alto, hx, 0]);   // normal del faldón derecho

    function cara(p0, p1, p2, p3, n) {
        const o = vertices.length / 8;
        [p0, p1, p2, p3].forEach((p, i) => {
            const uv = [[0,0],[1,0],[1,1],[0,1]][i];
            vertices.push(p[0], p[1], p[2], n[0], n[1], n[2], uv[0], uv[1]);
        });
        indices.push(o, o + 1, o + 2, o, o + 2, o + 3);
    }

    // Faldón derecho (+X) e izquierdo (-X)
    cara([hx,0,hz], [hx,0,-hz], [0,alto,-hz], [0,alto,hz], pend);
    cara([-hx,0,-hz], [-hx,0,hz], [0,alto,hz], [0,alto,-hz], [-pend[0], pend[1], 0]);

    // Frontones triangulares (±Z)
    [[1, hz], [-1, -hz]].forEach(([s, z]) => {
        const o = vertices.length / 8;
        vertices.push(-hx * s, 0, z, 0, 0, s, 0, 0);
        vertices.push(hx * s, 0, z, 0, 0, s, 1, 0);
        vertices.push(0, alto, z, 0, 0, s, 0.5, 1);
        indices.push(o, o + 1, o + 2);
    });

    // Cara inferior
    cara([-hx,0,hz], [-hx,0,-hz], [hx,0,-hz], [hx,0,hz], [0,-1,0]);

    return { vertices: new Float32Array(vertices), indices: new Uint16Array(indices) };
}

// ============================================================
// 3. CONFIGURACIÓN DE LA ALDEA
function crearTerreno(segmentos) {

    const paso = (MEDIO_TERRENO * 2) / segmentos;
    const vertices = [];
    const indices = [];
    const e = 0.25;

    for (let i = 0; i <= segmentos; i++) {
        const x = -MEDIO_TERRENO + i * paso;

        for (let j = 0; j <= segmentos; j++) {
            const z = -MEDIO_TERRENO + j * paso;
            const h = alturaTerreno(x, z);

            const dhdx = (alturaTerreno(x + e, z) - alturaTerreno(x - e, z)) / (2 * e);
            const dhdz = (alturaTerreno(x, z + e) - alturaTerreno(x, z - e)) / (2 * e);
            const n = normalizar([-dhdx, 1, -dhdz]);

            const arena = 1 - suave(0.05, 0.75, h);
            const roca = Math.max(suave(0.35, 0.65, 1 - n[1]), suave(6.0, 9.0, h));

            vertices.push(x, h, z, n[0], n[1], n[2], x / 40, z / 40, arena, roca);
        }
    }

    const col = segmentos + 1;

    for (let i = 0; i < segmentos; i++) {
        for (let j = 0; j < segmentos; j++) {
            const a = i * col + j;
            const b = a + col;
            indices.push(a, a + 1, b, b, a + 1, b + 1);
        }
    }

    return { vertices: new Float32Array(vertices), indices: new Uint16Array(indices) };
}

// ------------------------------------------------------------
// Cinta de agua que sigue el cauce.
// vértice = pos(3) flujo(2) uv(2) profundidad(1)
// ------------------------------------------------------------

function crearAgua(segLargo, segAncho) {

    const vertices = [];
    const indices = [];
    const largo = MEDIO_TERRENO * 2;

    for (let m = 0; m <= segAncho; m++) {
        const s = -ANCHO_AGUA + (2 * ANCHO_AGUA * m) / segAncho;

        for (let k = 0; k <= segLargo; k++) {
            const z = -MEDIO_TERRENO + (largo * k) / segLargo;
            const t = tangenteRio(z);          // (tx, tz)
            const px = rioX(z) + t[1] * s;     // normal transversal = (tz, -tx)
            const pz = z - t[0] * s;
            const prof = NIVEL_AGUA - alturaTerreno(px, pz);

            vertices.push(px, NIVEL_AGUA, pz, t[0], t[1], s, z, prof);
        }
    }

    const col = segLargo + 1;

    for (let m = 0; m < segAncho; m++) {
        for (let k = 0; k < segLargo; k++) {
            const a = m * col + k;
            const b = a + col;
            indices.push(a, a + 1, b, b, a + 1, b + 1);
        }
    }

    return { vertices: new Float32Array(vertices), indices: new Uint16Array(indices) };
}


export { crearCubo, crearEsfera, crearCilindro, crearToro, crearTecho, crearTerreno, crearAgua };
