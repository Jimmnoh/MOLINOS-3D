import { Geometry } from "../core/Geometry.js";
import { SphereGeometry } from "./SphereGeometry.js";
import { crearCubo, crearEsfera, crearCilindro, crearToro, crearTecho, crearTerreno, crearAgua } from "./generators.js";
export function createGeometries() {
const CAPAS_ESTANDAR = [3, 3, 2];

const mallas = {
    cubo:      new Geometry(crearCubo(), CAPAS_ESTANDAR),
    esfera:    new SphereGeometry(1, 20, 28),
    cilindro:  new Geometry(crearCilindro(1, 1, 1, 24), CAPAS_ESTANDAR),        // radio 1, altura 1
    cono:      new Geometry(crearCilindro(0, 1, 1, 24), CAPAS_ESTANDAR),        // radio 1, altura 1
    tronco:    new Geometry(crearCilindro(0.62, 1, 1, 28), CAPAS_ESTANDAR),     // torre del molino
    toro:      new Geometry(crearToro(1, 0.045, 40, 8), CAPAS_ESTANDAR),        // aro de rueda (radio 1)
    techo:     new Geometry(crearTecho(1, 1, 1), CAPAS_ESTANDAR),
    terreno:   new Geometry(crearTerreno(224), [3, 3, 2, 2]),
    agua:      new Geometry(crearAgua(240, 28), [3, 2, 2, 1])
};


return mallas;
}
