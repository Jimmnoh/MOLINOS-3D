import { Object3D } from '../core/Object3D.js';
import { Matrix4 } from '../math/Matrix4.js';
export class Camera extends Object3D {
    constructor() { super(); this.target=[0,0,0]; this.up=[0,1,0]; this.viewMatrix=Matrix4.identidad(); this.projectionMatrix=Matrix4.identidad(); }
    updateViewMatrix() {
        const m=this.matrixWorld;
        this.eye=[m[12],m[13],m[14]];
        this.viewMatrix=Matrix4.lookAt(this.eye,this.target,this.up);
    }
}
