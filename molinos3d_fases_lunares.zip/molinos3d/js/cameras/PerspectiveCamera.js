import { Camera } from './Camera.js';
import { Matrix4 } from '../math/Matrix4.js';
export class PerspectiveCamera extends Camera {
    constructor(fov=58,aspect=1,near=0.2,far=400) { super(); Object.assign(this,{fov,aspect,near,far}); this.updateProjectionMatrix(); }
    updateProjectionMatrix() { this.projectionMatrix=Matrix4.perspectiva(this.fov*Math.PI/180,this.aspect,this.near,this.far); }
}
