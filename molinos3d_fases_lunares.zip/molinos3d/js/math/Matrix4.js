function identidad4() {
    return new Float32Array([
        1,0,0,0,
        0,1,0,0,
        0,0,1,0,
        0,0,0,1
    ]);
}

function multiplicarMat4(a, b) {

    const r = new Float32Array(16);

    for (let c = 0; c < 4; c++) {
        for (let f = 0; f < 4; f++) {
            for (let k = 0; k < 4; k++) {
                r[c * 4 + f] += a[k * 4 + f] * b[c * 4 + k];
            }
        }
    }

    return r;
}

function traslacion(x, y, z) {
    return new Float32Array([
        1,0,0,0,
        0,1,0,0,
        0,0,1,0,
        x,y,z,1
    ]);
}

function escala(x, y, z) {
    return new Float32Array([
        x,0,0,0,
        0,y,0,0,
        0,0,z,0,
        0,0,0,1
    ]);
}

function rotacionX(a) {
    const c = Math.cos(a), s = Math.sin(a);
    return new Float32Array([
        1,0,0,0,
        0,c,s,0,
        0,-s,c,0,
        0,0,0,1
    ]);
}

function rotacionY(a) {
    const c = Math.cos(a), s = Math.sin(a);
    return new Float32Array([
        c,0,-s,0,
        0,1,0,0,
        s,0,c,0,
        0,0,0,1
    ]);
}

function rotacionZ(a) {
    const c = Math.cos(a), s = Math.sin(a);
    return new Float32Array([
        c,s,0,0,
        -s,c,0,0,
        0,0,1,0,
        0,0,0,1
    ]);
}

// Atajo: compone varias matrices de izquierda a derecha.
function componer(...matrices) {
    let r = matrices[0];
    for (let i = 1; i < matrices.length; i++) {
        r = multiplicarMat4(r, matrices[i]);
    }
    return r;
}

function restar(a, b) { return [a[0]-b[0], a[1]-b[1], a[2]-b[2]]; }

function normalizar(v) {
    const l = Math.hypot(v[0], v[1], v[2]) || 1;
    return [v[0]/l, v[1]/l, v[2]/l];
}

function cruz(a, b) {
    return [
        a[1]*b[2] - a[2]*b[1],
        a[2]*b[0] - a[0]*b[2],
        a[0]*b[1] - a[1]*b[0]
    ];
}

function lookAt(eye, target, up) {

    const z = normalizar(restar(eye, target));
    const x = normalizar(cruz(up, z));
    const y = cruz(z, x);

    return new Float32Array([
        x[0], y[0], z[0], 0,
        x[1], y[1], z[1], 0,
        x[2], y[2], z[2], 0,
        -(x[0]*eye[0] + x[1]*eye[1] + x[2]*eye[2]),
        -(y[0]*eye[0] + y[1]*eye[1] + y[2]*eye[2]),
        -(z[0]*eye[0] + z[1]*eye[1] + z[2]*eye[2]),
        1
    ]);
}

function perspectiva(fov, aspect, near, far) {

    const f = 1 / Math.tan(fov / 2);
    const nf = 1 / (near - far);

    return new Float32Array([
        f / aspect, 0, 0, 0,
        0, f, 0, 0,
        0, 0, (far + near) * nf, -1,
        0, 0, 2 * far * near * nf, 0
    ]);
}

function ortografica(l, r, b, t, n, f) {
    return new Float32Array([
        2/(r-l), 0, 0, 0,
        0, 2/(t-b), 0, 0,
        0, 0, -2/(f-n), 0,
        -(r+l)/(r-l), -(t+b)/(t-b), -(f+n)/(f-n), 1
    ]);
}


export class Matrix4 {
    static identidad4 = identidad4;
    static multiplicarMat4 = multiplicarMat4;
    static traslacion = traslacion;
    static escala = escala;
    static rotacionX = rotacionX;
    static rotacionY = rotacionY;
    static rotacionZ = rotacionZ;
    static componer = componer;
    static restar = restar;
    static normalizar = normalizar;
    static cruz = cruz;
    static lookAt = lookAt;
    static perspectiva = perspectiva;
    static ortografica = ortografica;

    static identidad = identidad4;
    static multiplicar = multiplicarMat4;
    static compose(p,r,s) {
        return componer(traslacion(p.x,p.y,p.z),rotacionZ(r.z),rotacionY(r.y),rotacionX(r.x),escala(s.x,s.y,s.z));
    }
}
export { identidad4, multiplicarMat4, traslacion, escala, rotacionX, rotacionY, rotacionZ, componer, restar, normalizar, cruz, lookAt, perspectiva, ortografica };
