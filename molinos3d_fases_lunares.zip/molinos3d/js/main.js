import { Renderer } from './core/Renderer.js';
import { PerspectiveCamera } from './cameras/PerspectiveCamera.js';
import { TextureLoader } from './utils/TextureLoader.js';
import { createGeometries } from './geometries/createGeometries.js';
import { loadTextures } from './scene/loadTextures.js';
import { createVillage } from './scene/createVillage.js';
import { ambiente, avanzarFaseLunar } from './scene/environment.js';
import { createControls } from './controls/VillageControls.js';

const canvas=document.getElementById('glCanvas');
const renderer=new Renderer(canvas);
const textures=loadTextures(new TextureLoader(renderer.gl));
const {scene,molinosViento,molinosAgua}=createVillage(createGeometries(),textures);
const camera=new PerspectiveCamera(58,1,0.2,400);
const controls=createControls(canvas,ambiente,molinosViento,molinosAgua,camera);
ambiente.quality='equilibrada';
document.getElementById('calidad').addEventListener('change',event=>{
    ambiente.quality=event.target.value;
});
let tiempoSim=0,previous=null,fps=60,elapsed=0;
function actualizarSimulacion(dt) {

    tiempoSim += dt;
    avanzarFaseLunar(dt);
    if(ambiente.fasesAuto || ambiente.cicloAuto) controls.actualizarEtiquetas();

    if (ambiente.cicloAuto) {
        ambiente.hora = (ambiente.hora + dt * 0.35) % 24;
        const slider=document.getElementById("hora"); if(slider) slider.value=ambiente.hora;
        controls.actualizarEtiquetas();
    }

    // El viento cambia lentamente de dirección; cada casquete lo sigue.
    ambiente.direccionViento = 0.9 * Math.sin(tiempoSim * 0.05) + 0.5 * Math.sin(tiempoSim * 0.131 + 1.0);

    molinosViento.forEach((m, i) => {
        const e = m.estado;
        const objetivoYaw = ambiente.direccionViento + 0.15 * Math.sin(i * 2.1 + tiempoSim * 0.2) - e.yawCuerpo;
        const dif = Math.atan2(Math.sin(objetivoYaw - e.yaw), Math.cos(objetivoYaw - e.yaw));
        e.yaw += dif * (1 - Math.exp(-dt * 0.8));
        e.angulo += e.vel * ambiente.viento * 1.4 * dt;
    });

    molinosAgua.forEach(m => {
        m.estado.angulo += m.estado.vel * ambiente.caudal * 0.55 * dt;
    });

    ambiente.tiempoFlujo += ambiente.caudal * dt;
}


function animate(ms) {
    const t=ms*0.001;
    const frameDt=previous===null ? 0 : t-previous;
    const dt=Math.min(frameDt,0.05); previous=t;
    if(!controls.paused) actualizarSimulacion(dt);
    controls.update(dt,t);
    renderer.render(scene,camera,{time:t,simulationTime:tiempoSim,environment:ambiente});
    if(frameDt>0) fps+=(1/frameDt-fps)*0.05;
    elapsed+=frameDt;
    if(elapsed>0.5) { elapsed=0; document.getElementById('fps').textContent=Math.round(fps)+' FPS'; }
    requestAnimationFrame(animate);
}
requestAnimationFrame(animate);
