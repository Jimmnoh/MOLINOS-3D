const SOMBRA_TAM = 1024;

// Código GLSL compartido: luz, cielo, niebla y sombras.
const GLSL_COMUN = `#version 300 es
precision highp float;

uniform vec3 uSunDir;
uniform vec3 uLightDir;
uniform vec3 uMoonDir;
uniform float uMoonPhase;
uniform float uMoonBrightness;
uniform vec3 uSunColor;
uniform vec3 uAmbSky;
uniform vec3 uAmbGround;
uniform vec3 uCamPos;
uniform float uNoche;
uniform float uDia;
uniform float uFogDensity;
uniform float uSombraFuerza;
uniform float uQuality;
uniform mat4 uLightVP;
uniform highp sampler2DShadow uShadowMap;

// Color del cielo en la dirección d (espacio lineal).
vec3 cieloBase(vec3 d) {

    float sy = uSunDir.y;
    float sunU = smoothstep(-0.18, 0.12, sy);
    float warm = exp(-pow(sy * 3.5, 2.0));

    vec2 hs = normalize(uSunDir.xz + vec2(1e-4));
    vec2 hd = normalize(d.xz + vec2(1e-4));
    float az = pow(max(dot(hs, hd), 0.0), 3.0);
    float atardecer = warm * (0.30 + 0.70 * az);

    vec3 zenD = vec3(0.027, 0.150, 0.690), horD = vec3(0.340, 0.600, 0.890);
    vec3 zenA = vec3(0.050, 0.070, 0.260), horA = vec3(1.000, 0.230, 0.050);
    vec3 zenN = vec3(0.002, 0.004, 0.015), horN = vec3(0.012, 0.018, 0.045);

    vec3 zen = mix(zenN, mix(zenD, zenA, warm * 0.6), sunU);
    vec3 hor = mix(horN, mix(horD, horA, atardecer), sunU);

    float g = pow(clamp(d.y, 0.0, 1.0), 0.45);
    vec3 c = mix(hor, zen, g);

    float sd = max(dot(d, uSunDir), 0.0);
    c += vec3(1.0, 0.65, 0.35) * (pow(sd, 6.0) * 0.25 + pow(sd, 64.0) * 0.5) * sunU;

    return c;
}

vec3 aplicarNiebla(vec3 c, vec3 wp) {

    vec3 v = wp - uCamPos;
    float dist = length(v);
    float f = 1.0 - exp(-pow(dist * uFogDensity, 2.0));
    vec3 dirHorizonte = normalize(vec3(v.x, 0.02, v.z));

    return mix(c, cieloBase(dirHorizonte), clamp(f, 0.0, 1.0));
}

float sombraFactor(vec3 wp, vec3 N, float ndl) {
    if (uSombraFuerza <= 0.0) return 1.0;

    vec4 lp = uLightVP * vec4(wp + N * (0.05 + 0.10 * (1.0 - ndl)), 1.0);
    vec3 pc = lp.xyz / lp.w * 0.5 + 0.5;

    if (pc.x < 0.0 || pc.x > 1.0 || pc.y < 0.0 || pc.y > 1.0 || pc.z > 1.0) {
        return 1.0;
    }

    float texel = 1.0 / ${SOMBRA_TAM}.0;
    if(uQuality < 0.5) {
        return mix(1.0,texture(uShadowMap,vec3(pc.xy,pc.z-0.0004)),uSombraFuerza);
    }
    if(uQuality < 1.5) {
        float s4=texture(uShadowMap,vec3(pc.xy+vec2(-0.5,-0.5)*texel,pc.z-0.0004));
        s4+=texture(uShadowMap,vec3(pc.xy+vec2(0.5,-0.5)*texel,pc.z-0.0004));
        s4+=texture(uShadowMap,vec3(pc.xy+vec2(-0.5,0.5)*texel,pc.z-0.0004));
        s4+=texture(uShadowMap,vec3(pc.xy+vec2(0.5,0.5)*texel,pc.z-0.0004));
        return mix(1.0,s4*0.25,uSombraFuerza);
    }
    float s = 0.0;

    for (int x = -1; x <= 1; x++) {
        for (int y = -1; y <= 1; y++) {
            s += texture(uShadowMap, vec3(pc.xy + vec2(float(x), float(y)) * texel * 1.3, pc.z - 0.0004));
        }
    }

    return mix(1.0, s / 9.0, uSombraFuerza);
}
`;

// ---------------- Objetos (torres, aspas, árboles, ...) ----------------

const objetoVS = `#version 300 es
layout(location = 0) in vec3 aPosition;
layout(location = 1) in vec3 aNormal;
layout(location = 2) in vec2 aTexCoord;

layout(location = 4) in mat4 aModel;
layout(location = 8) in vec4 aColorEmissive;
layout(location = 9) in vec3 aUvShine;
flat out vec4 vColorEmissive;
flat out vec3 vUvShine;
uniform mat4 uView;
uniform mat4 uProj;

out vec3 vNormal;
out vec3 vWorld;
out vec2 vUV;

void main() {
    vec4 w = aModel * vec4(aPosition, 1.0);
    vWorld = w.xyz;
    vNormal = transpose(inverse(mat3(aModel))) * aNormal;
    vUV = aTexCoord;
    vColorEmissive = aColorEmissive;
    vUvShine = aUvShine;
    gl_Position = uProj * uView * w;
}
`;

const objetoFS = GLSL_COMUN + `
in vec3 vNormal;
in vec3 vWorld;
in vec2 vUV;

uniform sampler2D uTexture;
flat in vec4 vColorEmissive;
flat in vec3 vUvShine;

out vec4 outColor;

void main() {

    vec3 N = normalize(vNormal);
    if (!gl_FrontFacing) N = -N;

    vec3 L = normalize(uLightDir);
    float ndl = max(dot(N, L), 0.0);
    float sombra = sombraFactor(vWorld, N, ndl);

    vec3 albedo = pow(texture(uTexture, vUV * vUvShine.xy).rgb, vec3(2.2)) * vColorEmissive.rgb;
    vec3 hemi = mix(uAmbGround, uAmbSky, N.y * 0.5 + 0.5);

    vec3 V = normalize(uCamPos - vWorld);
    vec3 H = normalize(L + V);
    float spec = pow(max(dot(N, H), 0.0), 40.0) * vUvShine.z * ndl * sombra;

    vec3 c = albedo * (hemi + uSunColor * ndl * sombra) + uSunColor * spec;
    c += vColorEmissive.rgb * vColorEmissive.a * uNoche;     // ventanas encendidas de noche

    c = aplicarNiebla(c, vWorld);
    outColor = vec4(pow(c, vec3(1.0 / 2.2)), 1.0);
}
`;

// ---------------- Terreno (mezcla de 3 texturas) ----------------

const terrenoVS = `#version 300 es
layout(location = 0) in vec3 aPosition;
layout(location = 1) in vec3 aNormal;
layout(location = 2) in vec2 aTexCoord;
layout(location = 3) in vec2 aMezcla;

uniform mat4 uView;
uniform mat4 uProj;

out vec3 vNormal;
out vec3 vWorld;
out vec2 vMezcla;

void main() {
    vWorld = aPosition;
    vNormal = aNormal;
    vMezcla = aMezcla;
    gl_Position = uProj * uView * vec4(aPosition, 1.0);
}
`;

const terrenoFS = GLSL_COMUN + `
in vec3 vNormal;
in vec3 vWorld;
in vec2 vMezcla;

uniform sampler2D uPasto;
uniform sampler2D uTierra;
uniform sampler2D uRoca;

out vec4 outColor;

vec3 muestra(sampler2D t, vec2 p) {
    return pow(texture(t, p).rgb, vec3(2.2));
}

void main() {

    vec2 p = vWorld.xz;

    // Cada textura se muestrea a dos escalas para evitar repeticiones.
    vec3 pasto = muestra(uPasto, p * 0.22);
    vec3 tierra = muestra(uTierra, p * 0.30);
    vec3 roca = muestra(uRoca, p * 0.18);
    if(uQuality > 1.5) {
        pasto=mix(pasto,muestra(uPasto,p*0.047+0.37),0.45);
        tierra=mix(tierra,muestra(uTierra,p*0.07),0.40);
        roca=mix(roca,muestra(uRoca,p*0.05),0.40);
    }

    vec3 albedo = mix(pasto, tierra, clamp(vMezcla.x, 0.0, 1.0));
    albedo = mix(albedo, roca, clamp(vMezcla.y, 0.0, 1.0));

    float mojado = 1.0 - smoothstep(-0.1, 0.35, vWorld.y);
    albedo *= 1.0 - 0.45 * mojado;

    vec3 N = normalize(vNormal);
    vec3 L = normalize(uLightDir);
    float ndl = max(dot(N, L), 0.0);
    float sombra = sombraFactor(vWorld, N, ndl);

    vec3 hemi = mix(uAmbGround, uAmbSky, N.y * 0.5 + 0.5);
    vec3 c = albedo * (hemi + uSunColor * ndl * sombra);

    c = aplicarNiebla(c, vWorld);
    outColor = vec4(pow(c, vec3(1.0 / 2.2)), 1.0);
}
`;

// ---------------- Agua del río ----------------

const aguaVS = `#version 300 es
layout(location = 0) in vec3 aPosition;
layout(location = 1) in vec2 aFlow;
layout(location = 2) in vec2 aUV;
layout(location = 3) in float aDepth;

uniform mat4 uView;
uniform mat4 uProj;
uniform float uFlowTime;

out vec3 vWorld;
out vec2 vUV;
out vec2 vFlow;
out float vDepth;
out vec3 vNormalOnda;

void main() {

    vec3 p = aPosition;

    // Calma cerca de la orilla (poca profundidad = menos oleaje).
    float calma = smoothstep(0.0, 0.5, aDepth);

    // Tres ondas senoidales que viajan río abajo.
    vec2 d1 = normalize(vec2(0.08, 1.0));   float k1 = 1.7;
    vec2 d2 = normalize(vec2(0.90, 0.35));  float k2 = 2.6;
    vec2 d3 = normalize(vec2(-0.60, 0.80)); float k3 = 4.1;

    float f1 = k1 * dot(d1, p.xz) - 1.9 * uFlowTime;
    float f2 = k2 * dot(d2, p.xz) - 2.4 * uFlowTime;
    float f3 = k3 * dot(d3, p.xz) - 3.1 * uFlowTime;

    p.y += calma * (0.030 * sin(f1) + 0.016 * sin(f2) + 0.008 * sin(f3));

    vec2 grad = calma * (0.030 * k1 * cos(f1) * d1
                       + 0.016 * k2 * cos(f2) * d2
                       + 0.008 * k3 * cos(f3) * d3);

    vNormalOnda = normalize(vec3(-grad.x, 1.0, -grad.y));
    vWorld = p;
    vUV = aUV;
    vFlow = aFlow;
    vDepth = aDepth;

    gl_Position = uProj * uView * vec4(p, 1.0);
}
`;

const aguaFS = GLSL_COMUN + `
in vec3 vWorld;
in vec2 vUV;
in vec2 vFlow;
in float vDepth;
in vec3 vNormalOnda;

uniform sampler2D uNormalMap;
uniform sampler2D uEspuma;
uniform float uFlowTime;
uniform vec4 uSalp[8];
uniform int uNumSalp;

out vec4 outColor;

void main() {

    vec2 across = vec2(vFlow.y, -vFlow.x);

    // Dos capas del mapa de normales que se desplazan con la corriente.
    vec3 n1 = texture(uNormalMap, vUV * 0.21 + vec2(0.0, -uFlowTime * 0.16)).xyz * 2.0 - 1.0;
    vec3 n2 = texture(uNormalMap, vUV * 0.47 + vec2(0.13, -uFlowTime * 0.27)).xyz * 2.0 - 1.0;
    vec2 pert = (n1.xy + n2.xy * 0.6) * 0.35;

    vec3 N = normalize(vNormalOnda + vec3(
        across.x * pert.x + vFlow.x * pert.y, 0.0,
        across.y * pert.x + vFlow.y * pert.y));

    vec3 V = normalize(uCamPos - vWorld);
    vec3 L = normalize(uLightDir);

    // Fresnel: más reflejo del cielo a ángulos rasantes.
    float F = 0.02 + 0.98 * pow(1.0 - max(dot(N, V), 0.0), 5.0);
    vec3 R = reflect(-V, N);
    R.y = abs(R.y);
    vec3 reflejo = cieloBase(normalize(R));

    // Color propio del agua según la profundidad.
    vec3 somera = vec3(0.045, 0.200, 0.170);
    vec3 honda = vec3(0.004, 0.040, 0.090);
    vec3 base = mix(somera, honda, smoothstep(0.05, 1.0, vDepth));
    base *= 0.25 + 0.75 * uDia;
    base += uSunColor * 0.03 * max(dot(N, L), 0.0);

    vec3 col = mix(base, reflejo, clamp(F * 1.15, 0.0, 1.0));

    // Brillo especular del sol (o de la luna).
    vec3 H = normalize(L + V);
    float nh = max(dot(N, H), 0.0);
    col += uSunColor * (pow(nh, 220.0) * 1.6 + pow(nh, 30.0) * 0.06);

    // Espuma en la orilla y alrededor de cada rueda.
    float ruido = texture(uEspuma, vUV * 0.35 + vec2(0.0, -uFlowTime * 0.20)).r;
    float espuma = smoothstep(0.32, 0.0, vDepth) * (0.35 + 0.65 * ruido);

    for (int i = 0; i < 8; i++) {
        if (i >= uNumSalp) break;
        float r = length(vWorld.xz - uSalp[i].xy) / uSalp[i].z;
        espuma += smoothstep(1.0, 0.2, r) * ruido * 0.9;
    }

    espuma = clamp(espuma, 0.0, 1.0);
    col = mix(col, vec3(0.90, 0.95, 1.00) * (0.12 + 0.88 * uDia), espuma);

    float alfa = mix(0.45, 0.95, smoothstep(0.0, 0.9, vDepth));
    alfa = max(alfa, F);
    alfa = max(alfa, espuma * 0.9);
    alfa *= smoothstep(0.0, 0.10, vDepth);

    col = aplicarNiebla(col, vWorld);
    outColor = vec4(pow(col, vec3(1.0 / 2.2)), alfa);
}
`;

// ---------------- Cielo (pantalla completa) ----------------

const cieloVS = `#version 300 es
out vec2 vNdc;

void main() {
    vec2 p = vec2(float((gl_VertexID << 1) & 2), float(gl_VertexID & 2));
    vNdc = p * 2.0 - 1.0;
    gl_Position = vec4(vNdc, 1.0, 1.0);
}
`;

const cieloFS = GLSL_COMUN + `
in vec2 vNdc;

uniform vec3 uRight;
uniform vec3 uUp;
uniform vec3 uFwd;
uniform float uTan;
uniform float uAspect;
uniform float uTime;

out vec4 outColor;

float hash(vec2 p) {
    return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453);
}

float noise(vec2 p) {
    vec2 i = floor(p), f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    return mix(mix(hash(i), hash(i + vec2(1, 0)), f.x),
               mix(hash(i + vec2(0, 1)), hash(i + vec2(1, 1)), f.x), f.y);
}

float fbm(vec2 p) {
    float a = 0.5, s = 0.0;
    for (int i = 0; i < 5; i++) {
        if(i >= (uQuality < 0.5 ? 2 : (uQuality < 1.5 ? 3 : 5))) break;
        s += a * noise(p);
        p = p * 2.03 + vec2(17.0, 9.0);
        a *= 0.5;
    }
    return s;
}

void main() {

    vec3 d = normalize(uFwd + vNdc.x * uAspect * uTan * uRight + vNdc.y * uTan * uUp);
    float sunU = smoothstep(-0.18, 0.12, uSunDir.y);

    vec3 c = cieloBase(d);

    // Disco del sol y de la luna.
    float sd = dot(d, uSunDir);
    c += vec3(1.0, 0.92, 0.75) * smoothstep(0.99955, 0.99985, sd) * 6.0 * sunU;
    // Disco esferico iluminado: el terminador dibuja crecientes y menguantes.
    vec3 moonDir=normalize(uMoonDir);
    vec3 moonRight=cross(moonDir,vec3(0.0,1.0,0.0));
    moonRight=length(moonRight)>0.001 ? normalize(moonRight) : vec3(1.0,0.0,0.0);
    vec3 moonUp=normalize(cross(moonRight,moonDir));
    float moonFacing=dot(d,moonDir);
    float phaseAngle=uMoonPhase*6.28318530718;
    float litFraction=(1.0-cos(phaseAngle))*0.5;
    float moonVisibility=smoothstep(-0.02,0.08,moonDir.y)*(1.0-sunU*0.85);
    float halo=pow(max(moonFacing,0.0),500.0);
    c+=vec3(0.09,0.14,0.26)*halo*litFraction*uMoonBrightness*moonVisibility;
    vec2 disk=vec2(dot(d,moonRight),dot(d,moonUp))/0.030;
    float radius2=dot(disk,disk);
    if(moonFacing>0.0 && radius2<1.0) {
        vec3 sphereNormal=vec3(disk,sqrt(max(0.0,1.0-radius2)));
        vec3 phaseLight=vec3(sin(phaseAngle),0.0,-cos(phaseAngle));
        float lit=max(dot(sphereNormal,phaseLight),0.0);
        float edge=1.0-smoothstep(0.94,1.0,radius2);
        // Un leve relieve procedural evita un disco completamente plano.
        float maria=0.88+0.12*sin(disk.x*15.0+sin(disk.y*11.0))*sin(disk.y*13.0);
        vec3 moonColor=vec3(0.78,0.86,1.0)*(0.012+lit*3.8)*maria*uMoonBrightness;
        c=mix(c,moonColor,edge*moonVisibility);
    }

    if (d.y > 0.0) {

        // Estrellas con parpadeo.
        vec2 sp = d.xz / (d.y + 0.35) * 55.0;
        float h = hash(floor(sp));
        float estrella = step(0.992, h) * smoothstep(0.35, 0.0, length(fract(sp) - 0.5));
        estrella *= 0.7 + 0.3 * sin(uTime * 3.0 + h * 40.0);
        c += estrella * (1.0 - sunU) * vec3(0.9, 0.95, 1.0) * 1.2;

        // Nubes: ruido fractal proyectado sobre un plano alto.
        vec2 q = d.xz / (d.y + 0.12) * 1.2 + vec2(uTime * 0.012, uTime * 0.004);
        float cob = smoothstep(0.50, 0.80, fbm(q)) * smoothstep(0.0, 0.18, d.y);

        vec3 horizonte = cieloBase(normalize(vec3(d.x, 0.02, d.z)));
        vec3 nube = mix(vec3(0.62, 0.64, 0.70), vec3(1.0), smoothstep(0.35, 0.75, fbm(q + 3.1)));
        nube = mix(nube * (0.08 + 0.92 * sunU), horizonte * 1.4, (1.0 - sunU) * 0.2 + 0.3 * (1.0 - smoothstep(0.0, 0.5, d.y)) * sunU);
        c = mix(c, nube, cob * 0.92);
    }

    outColor = vec4(pow(min(c, vec3(1.6)), vec3(1.0 / 2.2)), 1.0);
}
`;

// ---------------- Pasada de sombras ----------------

const sombraVS = `#version 300 es
layout(location = 0) in vec3 aPosition;
uniform mat4 uModel;
uniform bool uInstanced;
layout(location = 4) in mat4 aModel;
uniform mat4 uLightVP;

void main() {
    gl_Position = uLightVP * (uInstanced ? aModel : uModel) * vec4(aPosition, 1.0);
}
`;

const sombraFS = `#version 300 es
precision highp float;
out vec4 outColor;
void main() { outColor = vec4(1.0); }
`;

// ============================================================
// 7. PROGRAMAS WEBGL
// ============================================================


export { SOMBRA_TAM,objetoVS,objetoFS,terrenoVS,terrenoFS,aguaVS,aguaFS,cieloVS,cieloFS,sombraVS,sombraFS };
