export class BasicMaterial {
    constructor({texture=null,color=[1,1,1],uv=[1,1],brillo=0,emissive=0}={}) {
        Object.assign(this,{texture,color,uv,brillo,emissive});
    }
}
