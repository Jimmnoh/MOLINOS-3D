import { identidad4, multiplicarMat4, traslacion, escala, rotacionX, rotacionY, rotacionZ, componer, restar, normalizar, cruz, lookAt, perspectiva, ortografica } from "../math/Matrix4.js";
import { limitar, mezclar, suave, mezclarVec, crearRandom, hash2, ruido2, fbm2 } from "../utils/helpers.js";
import { NIVEL_AGUA, NIVEL_ORILLA, MEDIO_TERRENO, ANCHO_AGUA, configViento, configAgua, DIST_MOLINO_AGUA, rioX, rioDX, tangenteRio, distanciaRio, alturaBase, alturaCimas, alturaTerreno } from "../scene/terrain.js";
import { Object3D } from '../core/Object3D.js';
import { Scene } from '../core/Scene.js';
import { Mesh } from '../objects/Mesh.js';
import { BasicMaterial } from '../materials/BasicMaterial.js';
export function createVillage(mallas,tex) {
const random=crearRandom(20262);
function crearNodo(op={}) {
    const node=op.malla ? new Mesh(op.malla,new BasicMaterial({texture:op.tex || tex.blanco,color:op.color,uv:op.uv,brillo:op.brillo,emissive:op.emisivo})) : new Object3D();
    node.base=op.base || identidad4(); node.anim=op.anim || null; node.castShadow=op.sombra!==false;
    return node;
}
function pieza(padre, malla, o = {}) {

    const p = o.pos || [0, 0, 0];
    let e = o.esc || [1, 1, 1];
    if (typeof e === "number") e = [e, e, e];

    const nodo = crearNodo({
        malla: malla,
        tex: o.tex,
        color: o.color,
        uv: o.uv,
        brillo: o.brillo,
        emisivo: o.emisivo,
        sombra: o.sombra,
        base: componer(
            traslacion(p[0], p[1], p[2]),
            rotacionY(o.rotY || 0),
            rotacionX(o.rotX || 0),
            rotacionZ(o.rotZ || 0),
            escala(e[0], e[1], e[2])
        )
    });

    padre.add(nodo);
    return nodo;
}

// Nodo vacío que solo agrupa y transforma a sus hijos.
function grupo(padre, base, anim) {
    const nodo = crearNodo({ base: base, anim: anim });
    padre.add(nodo);
    return nodo;
}

const MADERA_OSCURA = [0.62, 0.45, 0.32];

// ============================================================
// 12. MOLINO DE VIENTO
//     terreno -> torre -> casquete (gira hacia el viento) -> rotor -> aspas
// ============================================================

function crearMolinoViento(cfg) {

    const y = alturaTerreno(cfg.x, cfg.z);
    const yawCuerpo = random() * Math.PI * 2;

    const estado = {
        angulo: random() * Math.PI * 2,   // ángulo del rotor
        yaw: 0.0,                         // orientación del casquete (relativa a la torre)
        yawCuerpo: yawCuerpo,             // giro fijo de la torre en el mundo
        vel: cfg.vel
    };

    const raiz = crearNodo({
        base: componer(traslacion(cfg.x, y, cfg.z), rotacionY(yawCuerpo),
            escala(cfg.esc, cfg.esc, cfg.esc))
    });

    // --- Torre de piedra y enlucido (cilindro troncocónico)
    pieza(raiz, mallas.cilindro, { esc: [1.85, 0.55, 1.85], tex: tex.piedra, uv: [4, 1] });
    pieza(raiz, mallas.tronco, { pos: [0, 0.4, 0], esc: [1.6, 5.0, 1.6], tex: tex.ladrillo, uv: [3, 2] });
    pieza(raiz, mallas.cilindro, { pos: [0, 1.5, 0], esc: [1.72, 0.1, 1.72], tex: tex.madera, uv: [6, 1], color: MADERA_OSCURA });
    pieza(raiz, mallas.cilindro, { pos: [0, 3.9, 0], esc: [1.2, 0.08, 1.2], tex: tex.madera, uv: [6, 1], color: MADERA_OSCURA });

    // --- Puerta y ventanas (las ventanas se encienden de noche)
    pieza(raiz, mallas.cubo, { pos: [0, 1.05, 1.52], esc: [0.8, 1.3, 0.25], tex: tex.madera, color: MADERA_OSCURA });

    [Math.PI / 2, -Math.PI / 2, Math.PI, 2.5].forEach(a => {
        const r = 1.25;
        pieza(raiz, mallas.cubo, {
            pos: [r * Math.sin(a), 3.2, r * Math.cos(a)], rotY: a,
            esc: [0.34, 0.55, 0.18], color: [1.0, 0.72, 0.30], emisivo: 1.4
        });
    });

    // --- Casquete: gira para enfrentar el viento
    const casquete = grupo(raiz, traslacion(0, 5.4, 0), () => rotacionY(estado.yaw));

    pieza(casquete, mallas.cono, { pos: [0, -0.05, 0], esc: [1.4, 1.6, 1.4], tex: tex.teja, uv: [6, 3] });
    pieza(casquete, mallas.cilindro, { pos: [0, 0.8, 0], rotX: Math.PI / 2, esc: [0.09, 2.2, 0.09], tex: tex.madera });
    pieza(casquete, mallas.esfera, { pos: [0, 0.8, 2.2], esc: 0.28, tex: tex.piedra, color: [0.55, 0.55, 0.6], brillo: 0.6 });

    // --- Rotor: la rotación depende del ángulo = velocidad * tiempo
    const rotor = grupo(casquete, traslacion(0, 0.8, 2.25), () => rotacionZ(estado.angulo));

    for (let k = 0; k < 4; k++) {

        const aspa = grupo(rotor, rotacionZ(k * Math.PI / 2));

        // Larguero (brazo principal)
        pieza(aspa, mallas.cubo, { pos: [0, 2.0, 0], esc: [0.14, 3.7, 0.1], tex: tex.madera, uv: [1, 4] });

        // Vela de tela con un pequeño ángulo de ataque
        const vela = grupo(aspa, componer(traslacion(0, 2.4, 0.04), rotacionY(0.22)));
        pieza(vela, mallas.cubo, { pos: [0.46, 0, 0], esc: [0.85, 2.7, 0.03], tex: tex.tela, uv: [1, 2] });

        // Travesaños del entramado
        for (let i = 0; i < 6; i++) {
            pieza(aspa, mallas.cubo, { pos: [0.45, 0.75 + 0.62 * i, 0], esc: [0.95, 0.05, 0.07], tex: tex.madera });
        }
    }

    return { raiz, estado, cfg };
}

// ============================================================
// 13. MOLINO HIDRÁULICO
//     orilla -> edificio -> rueda (gira con la corriente) -> palas
// ============================================================

const RADIO_RUEDA = 1.75;

function crearRueda(padre, estado) {

    const R = RADIO_RUEDA;
    const rueda = grupo(padre, traslacion(1.95, 0.95, 0),
        () => rotacionX(estado.signo * estado.angulo));

    // Eje y cubo central (cilindros girados para quedar a lo largo de X)
    pieza(rueda, mallas.cilindro, { pos: [-0.6, 0, 0], rotZ: -Math.PI / 2, esc: [0.12, 1.2, 0.12], tex: tex.madera });
    pieza(rueda, mallas.cilindro, { pos: [-0.45, 0, 0], rotZ: -Math.PI / 2, esc: [0.26, 0.9, 0.26], tex: tex.madera, color: MADERA_OSCURA });

    // Dos aros laterales
    [-0.32, 0.32].forEach(x => {
        pieza(rueda, mallas.toro, { pos: [x, 0, 0], rotZ: -Math.PI / 2, esc: R, tex: tex.madera, color: MADERA_OSCURA });
    });

    // 12 palas radiales y 12 rayos
    for (let k = 0; k < 12; k++) {
        const a = k * Math.PI / 6;
        const pala = crearNodo({
            malla: mallas.cubo, tex: tex.madera, uv: [1, 1],
            base: componer(rotacionX(a), traslacion(0, R - 0.05, 0), escala(0.82, 0.42, 0.07))
        });
        rueda.add(pala);
    }

    for (let k = 0; k < 6; k++) {
        [-0.32, 0.32].forEach(x => {
            rueda.add(crearNodo({
                malla: mallas.cubo, tex: tex.madera, color: MADERA_OSCURA,
                base: componer(traslacion(x, 0, 0), rotacionX(k * Math.PI / 6), escala(0.07, 2 * R, 0.09))
            }));
        });
    }

    return rueda;
}

function crearMolinoAgua(cfg) {

    const t = tangenteRio(cfg.z);          // dirección de la corriente (x,z)
    const n = [t[1], -t[0]];               // dirección transversal

    // Posición en la orilla y orientación: el eje X local mira al río.
    const px = rioX(cfg.z) + cfg.lado * n[0] * DIST_MOLINO_AGUA;
    const pz = cfg.z + cfg.lado * n[1] * DIST_MOLINO_AGUA;
    const dx = -cfg.lado * n[0], dz = -cfg.lado * n[1];
    const yaw = Math.atan2(-dz, dx);

    // El eje Z local apunta a (-dz, dx). La rueda debe mover su parte baja
    // en el sentido de la corriente: según el signo, se gira +X o -X.
    const zLocalMundo = [-dz, dx];
    const signo = (zLocalMundo[0] * t[0] + zLocalMundo[1] * t[1]) > 0 ? -1 : 1;

    const estado = { angulo: random() * 6.28, signo: signo, vel: cfg.vel };

    const raiz = crearNodo({
        base: componer(traslacion(px, NIVEL_ORILLA, pz), rotacionY(yaw),
            escala(cfg.esc, cfg.esc, cfg.esc))
    });

    // --- Cimientos de piedra dentro del cauce
    pieza(raiz, mallas.cubo, { pos: [-0.1, -1.0, 0], esc: [3.2, 2.0, 4.0], tex: tex.piedra, uv: [2, 1] });

    // --- Muros con entramado de madera
    pieza(raiz, mallas.cubo, { pos: [0, 1.1, 0], esc: [3.0, 2.2, 3.6], tex: tex.ladrillo, uv: [2, 1.5], color: [1.0, 0.93, 0.82] });

    [[1.5, 1.8], [1.5, -1.8], [-1.5, 1.8], [-1.5, -1.8]].forEach(([x, z]) => {
        pieza(raiz, mallas.cubo, { pos: [x, 1.1, z], esc: [0.18, 2.24, 0.18], tex: tex.madera, color: MADERA_OSCURA });
    });

    [-1.8, 1.8].forEach(z => {
        pieza(raiz, mallas.cubo, { pos: [0, 2.2, z], esc: [3.2, 0.16, 0.16], tex: tex.madera, color: MADERA_OSCURA });
    });

    [-1.5, 1.5].forEach(x => {
        pieza(raiz, mallas.cubo, { pos: [x, 2.2, 0], esc: [0.16, 0.16, 3.8], tex: tex.madera, color: MADERA_OSCURA });
    });

    // --- Techo a dos aguas y chimenea
    pieza(raiz, mallas.techo, { pos: [0, 2.2, 0], esc: [3.9, 1.5, 4.2], tex: tex.teja, uv: [4, 3], color: [0.78, 0.55, 0.5] });
    pieza(raiz, mallas.cubo, { pos: [-0.7, 3.4, -0.9], esc: [0.5, 1.5, 0.5], tex: tex.piedra });

    // --- Puerta trasera y ventanas
    pieza(raiz, mallas.cubo, { pos: [-1.5, 0.8, 0], esc: [0.14, 1.3, 0.9], tex: tex.madera, color: MADERA_OSCURA });

    [-1, 1].forEach(s => {
        pieza(raiz, mallas.cubo, { pos: [0.2, 1.4, s * 1.82], esc: [0.7, 0.6, 0.1], color: [1.0, 0.72, 0.30], emisivo: 1.4 });
        pieza(raiz, mallas.cubo, { pos: [-0.9, 1.4, s * 1.82], esc: [0.5, 0.6, 0.1], color: [1.0, 0.72, 0.30], emisivo: 1.4 });
    });

    // --- Rueda hidráulica
    crearRueda(raiz, estado);

    // Punto de salpicadura (parte baja de la rueda) para la espuma del agua.
    const c = Math.cos(yaw), s = Math.sin(yaw);
    const wx = px + (1.95 * cfg.esc) * c;
    const wz = pz - (1.95 * cfg.esc) * s;

    return { raiz, estado, cfg, salpicadura: [wx, wz, 1.25 * cfg.esc] };
}

// ============================================================
// 14. ÁRBOLES, ROCAS, CAÑAS Y PUENTE (objetos estáticos)
// ============================================================

function crearPino(x, z, s) {

    const y = alturaTerreno(x, z);
    const raiz = crearNodo({ base: componer(traslacion(x, y - 0.05, z), rotacionY(random() * 6.28), escala(s, s, s)) });
    const tono = 0.75 + random() * 0.35;
    const col = [tono * 0.8, tono, tono * 0.8];

    pieza(raiz, mallas.cilindro, { esc: [0.16, 1.3, 0.16], tex: tex.corteza, uv: [1, 2] });
    pieza(raiz, mallas.cono, { pos: [0, 0.8, 0], esc: [1.05, 1.5, 1.05], tex: tex.hojas, uv: [3, 2], color: col });
    pieza(raiz, mallas.cono, { pos: [0, 1.6, 0], esc: [0.8, 1.3, 0.8], tex: tex.hojas, uv: [3, 2], color: col });
    pieza(raiz, mallas.cono, { pos: [0, 2.4, 0], esc: [0.55, 1.1, 0.55], tex: tex.hojas, uv: [3, 2], color: col });

    return raiz;
}

function crearArbolFrondoso(x, z, s) {

    const y = alturaTerreno(x, z);
    const raiz = crearNodo({ base: componer(traslacion(x, y - 0.05, z), rotacionY(random() * 6.28), escala(s, s, s)) });

    // Algunos árboles con follaje otoñal
    const otono = random() < 0.14;
    const v = random();
    const col = otono ? [1.5, 0.85 + 0.3 * v, 0.35] : [0.8 + 0.4 * v, 0.85 + 0.3 * v, 0.7 + 0.3 * v];

    pieza(raiz, mallas.cilindro, { esc: [0.19, 1.7, 0.19], tex: tex.corteza, uv: [1, 2] });
    pieza(raiz, mallas.esfera, { pos: [0, 2.2, 0], esc: [1.15, 0.95, 1.15], tex: tex.hojas, uv: [2, 1], color: col });
    pieza(raiz, mallas.esfera, { pos: [0.55, 2.8, 0.25], esc: [0.8, 0.7, 0.8], tex: tex.hojas, uv: [2, 1], color: col });
    pieza(raiz, mallas.esfera, { pos: [-0.5, 2.7, -0.3], esc: [0.75, 0.65, 0.75], tex: tex.hojas, uv: [2, 1], color: col });

    return raiz;
}

function crearRoca(x, z, s) {

    const y = alturaTerreno(x, z);
    const raiz = crearNodo({ base: traslacion(x, y - 0.08 * s, z) });

    pieza(raiz, mallas.esfera, {
        rotY: random() * 6.28,
        esc: [s * (0.9 + random() * 0.5), s * 0.6, s * (0.8 + random() * 0.5)],
        tex: tex.roca, uv: [1, 1], color: [0.9 + random() * 0.2, 0.9 + random() * 0.2, 0.9 + random() * 0.2]
    });

    return raiz;
}

function crearCanas(x, z) {

    const y = alturaTerreno(x, z);
    const raiz = crearNodo({ base: traslacion(x, y - 0.05, z) });

    for (let i = 0; i < 3; i++) {
        pieza(raiz, mallas.cilindro, {
            pos: [(random() - 0.5) * 0.4, 0, (random() - 0.5) * 0.4],
            rotX: (random() - 0.5) * 0.35, rotZ: (random() - 0.5) * 0.35,
            esc: [0.025, 0.8 + random() * 0.6, 0.025],
            tex: tex.hojas, color: [1.1, 1.2, 0.6], sombra: false
        });
    }

    return raiz;
}

function crearPuente(zCentro) {

    const t = tangenteRio(zCentro);
    const n = [t[1], -t[0]];
    const raiz = crearNodo({
        base: componer(traslacion(rioX(zCentro), NIVEL_ORILLA, zCentro), rotacionY(Math.atan2(-n[1], n[0])))
    });

    const ang = Math.atan2(0.5, 3.0);

    // Tramo central y dos rampas
    [
        { x: 0, y: 0.55, rot: 0, largo: 5.0 },
        { x: 4.0, y: 0.30, rot: -ang, largo: 3.1 },
        { x: -4.0, y: 0.30, rot: ang, largo: 3.1 }
    ].forEach(seg => {
        const g = grupo(raiz, componer(traslacion(seg.x, seg.y, 0), rotacionZ(seg.rot)));
        pieza(g, mallas.cubo, { esc: [seg.largo, 0.16, 2.0], tex: tex.madera, uv: [3, 1] });

        [-0.92, 0.92].forEach(z => {
            pieza(g, mallas.cubo, { pos: [0, 0.6, z], esc: [seg.largo, 0.07, 0.08], tex: tex.madera, color: MADERA_OSCURA });
            [-1, 1].forEach(e => {
                pieza(g, mallas.cubo, { pos: [e * (seg.largo / 2 - 0.08), 0.3, z], esc: [0.09, 0.62, 0.09], tex: tex.madera, color: MADERA_OSCURA });
            });
        });
    });

    // Pilares de piedra dentro del agua
    [-2.4, 2.4].forEach(x => {
        pieza(raiz, mallas.cubo, { pos: [x, -0.5, 0], esc: [0.5, 2.1, 1.7], tex: tex.piedra });
    });

    return raiz;
}

// ============================================================
// 15. CONSTRUCCIÓN DE LA ALDEA
// ============================================================

const molinosViento = configViento.map(crearMolinoViento);
const molinosAgua = configAgua.map(crearMolinoAgua);

const Z_PUENTE = 8;
const estaticos = [crearPuente(Z_PUENTE)];

// Puntos que los árboles y las rocas deben evitar.
const zonasOcupadas = [];
configViento.forEach(m => zonasOcupadas.push([m.x, m.z, 7.5]));
molinosAgua.forEach(m => zonasOcupadas.push([m.raiz.base[12], m.raiz.base[14], 7.0]));
zonasOcupadas.push([rioX(Z_PUENTE), Z_PUENTE, 8.0]);

function ocupado(x, z, margen = 0) {
    return zonasOcupadas.some(([cx, cz, r]) => Math.hypot(x - cx, z - cz) < r + margen);
}

// Árboles
let arboles = 0, intentos = 0;
while (arboles < 85 && intentos < 2000) {
    intentos++;
    const x = (random() - 0.5) * 100;
    const z = (random() - 0.5) * 100;
    const h = alturaTerreno(x, z);

    if (distanciaRio(x, z) < 6.0 || h < 0.3 || h > 8 || ocupado(x, z)) continue;

    const s = 0.8 + random() * 0.8;
    estaticos.push((h > 2.2 || random() < 0.5) ? crearPino(x, z, s) : crearArbolFrondoso(x, z, s));
    arboles++;
}

// Rocas y cañas en las orillas
for (let i = 0; i < 34; i++) {
    const z = (random() - 0.5) * 100;
    const lado = random() < 0.5 ? -1 : 1;
    const d = 3.3 + random() * 1.8;
    const t = tangenteRio(z);
    const x = rioX(z) + lado * t[1] * d;
    const zz = z - lado * t[0] * d;

    if (!ocupado(x, zz, -2)) estaticos.push(crearRoca(x, zz, 0.25 + random() * 0.45));
}

for (let i = 0; i < 42; i++) {
    const z = (random() - 0.5) * 100;
    const lado = random() < 0.5 ? -1 : 1;
    const d = 3.0 + random() * 0.5;
    const t = tangenteRio(z);
    const x = rioX(z) + lado * t[1] * d;
    const zz = z - lado * t[0] * d;

    if (!ocupado(x, zz, -2)) estaticos.push(crearCanas(x, zz));
}


const scene=new Scene();
for(const node of estaticos) scene.add(node);
for(const m of [...molinosViento,...molinosAgua]) scene.add(m.raiz);
scene.mallas=mallas; scene.textures=tex; scene.molinosAgua=molinosAgua;
return {scene,molinosViento,molinosAgua};
}
