export function loadTextures(loader) {
const tex = {
    pasto:    loader.load("texturas/pasto.jpg",    [70, 120, 50]),
    tierra:   loader.load("texturas/tierra.jpg",   [130, 108, 80]),
    roca:     loader.load("texturas/roca.jpg",     [115, 112, 106]),
    ladrillo: loader.load("texturas/ladrillo.jpg", [205, 178, 138]),
    piedra:   loader.load("texturas/piedra.jpg",   [125, 120, 112]),
    madera:   loader.load("texturas/madera.jpg",   [140, 96, 54]),
    teja:     loader.load("texturas/teja.jpg",     [160, 55, 40]),
    tela:     loader.load("texturas/tela.jpg",     [235, 228, 208]),
    hojas:    loader.load("texturas/hojas.jpg",    [50, 100, 45]),
    corteza:  loader.load("texturas/corteza.jpg",  [80, 60, 44]),
    aguaNormal: loader.load("texturas/agua_normal.png", [128, 128, 255]),
    espuma:   loader.load("texturas/espuma.png",   [200, 200, 200]),
    blanco:   loader.createColor(255, 255, 255)
};


return tex;
}
