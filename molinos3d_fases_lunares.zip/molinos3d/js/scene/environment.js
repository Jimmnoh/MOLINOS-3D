import { normalizar } from "../math/Matrix4.js";
import { limitar, mezclar, suave, mezclarVec, crearRandom, hash2, ruido2, fbm2 } from "../utils/helpers.js";
const ambiente = {
    viento: 1.2,        // multiplicador de la velocidad de las aspas
    caudal: 1.0,        // multiplicador de la corriente del río y de las ruedas
    hora: 10.5,         // hora del día (0-24)
    cicloAuto: false,   // avanza la hora automáticamente
    diaLunar: 14.765,   // 0 nueva; mitad del ciclo llena
    brilloLunar: 1.7,
    fasesAuto: false,
    sombras: true,
    tiempoFlujo: 0,     // tiempo acumulado del agua (no salta al cambiar el caudal)
    direccionViento: 0  // ángulo actual del viento (rad)
};

const MES_LUNAR = 29.53;
function obtenerFaseLunar(dia = ambiente.diaLunar) {
    const fase=((dia / MES_LUNAR) % 1 + 1) % 1;
    const iluminada=(1-Math.cos(fase*Math.PI*2))*0.5;
    const nombres=['Nueva','Creciente','Cuarto creciente','Gibosa creciente',
        'Llena','Gibosa menguante','Cuarto menguante','Menguante'];
    return {fase,iluminada,nombre:nombres[Math.round(fase*8)%8]};
}

function avanzarFaseLunar(dt) {
    // Modo demostracion: dos minutos por ciclo; con dia/noche, un mes por 29,53 dias.
    const diasPorSegundo=ambiente.fasesAuto ? MES_LUNAR/120 : ambiente.cicloAuto ? 0.35/24 : 0;
    ambiente.diaLunar=((ambiente.diaLunar+Math.max(0,dt)*diasPorSegundo)%MES_LUNAR+MES_LUNAR)%MES_LUNAR;
}

function calcularIluminacion() {

    // 6h = amanecer, 12h = mediodía, 18h = atardecer
    const ang = (ambiente.hora - 6) / 12 * Math.PI;
    const sol = normalizar([Math.cos(ang), Math.sin(ang), 0.35]);
    const sy = sol[1];

    const dia = suave(-0.05, 0.25, sy);
    const calido = Math.exp(-Math.pow(sy * 3.2, 2));

    const colSol = mezclarVec([1.30, 1.12, 0.92], [1.35, 0.62, 0.28], calido * 0.9)
        .map(v => v * suave(0.0, 0.22, sy));
    const faseLunar=obtenerFaseLunar();
    const faseAngulo=faseLunar.fase*Math.PI*2;
    // La luna cambia su separacion angular respecto del sol con la fase.
    const luna=normalizar([Math.cos(ang-faseAngulo),Math.sin(ang-faseAngulo),0.35*Math.cos(faseAngulo)]);
    const noche=1-suave(-0.12,0.12,sy);
    const fuerzaLunar=faseLunar.iluminada*suave(0,0.20,luna[1])*ambiente.brilloLunar*noche;
    const colLuna = [0.55, 0.66, 0.95].map(v => v*fuerzaLunar);

    const delSol = sy >= 0;

    return {
        sol: sol,
        luna,
        faseLunar: faseLunar.fase,
        brilloLunar: ambiente.brilloLunar,
        luz: delSol ? sol : luna,
        colorLuz: delSol ? colSol : colLuna,
        ambCielo: mezclarVec([0.018, 0.028, 0.055], [0.20, 0.28, 0.45], dia).map((v,i)=>v+[0.035,0.045,0.070][i]*fuerzaLunar),
        ambSuelo: mezclarVec([0.009, 0.012, 0.020], [0.10, 0.08, 0.05], dia).map((v,i)=>v+[0.012,0.018,0.028][i]*fuerzaLunar),
        noche,
        dia: 0.05 + 0.95 * dia
    };
}


export { ambiente, calcularIluminacion, MES_LUNAR, obtenerFaseLunar, avanzarFaseLunar };

