import { identidad4, multiplicarMat4, traslacion, escala, rotacionX, rotacionY, rotacionZ, componer, restar, normalizar, cruz, lookAt, perspectiva, ortografica } from "../math/Matrix4.js";
import { limitar, mezclar, suave, mezclarVec, crearRandom, hash2, ruido2, fbm2 } from "../utils/helpers.js";
const NIVEL_AGUA = 0.0;       // altura de la superficie del río
const NIVEL_ORILLA = 0.45;    // altura de las orillas planas
const MEDIO_TERRENO = 56;     // el terreno cubre de -56 a +56 en X y Z
const ANCHO_AGUA = 4.3;       // semiancho de la cinta de agua

// Molinos de viento: sobre colinas, lejos del río.
const configViento = [
    { x: -21, z: -13, esc: 1.10, vel: 1.00 },
    { x: -25, z:   7, esc: 1.00, vel: 0.85 },
    { x:  22, z:  -7, esc: 1.00, vel: 1.10 },
    { x:  19, z:  15, esc: 1.20, vel: 0.90 },
    { x: -14, z:  26, esc: 0.85, vel: 1.20 }
];

// Molinos hidráulicos: en la orilla (lado -1 = izquierda, +1 = derecha).
const configAgua = [
    { z: -22, lado: -1, esc: 1.00, vel: 1.00 },
    { z:  -3, lado:  1, esc: 1.05, vel: 0.90 },
    { z:  16, lado: -1, esc: 0.95, vel: 1.10 }
];

const DIST_MOLINO_AGUA = 3.45;   // distancia del eje del río al centro del molino

// ============================================================
// 4. RÍO Y TERRENO (alturas calculadas por código)
// ============================================================

function rioX(z) {
    return 5.0 * Math.sin(z * 0.085) + 2.0 * Math.sin(z * 0.21 + 1.3);
}

function rioDX(z) {
    return 5.0 * 0.085 * Math.cos(z * 0.085) + 2.0 * 0.21 * Math.cos(z * 0.21 + 1.3);
}

// Dirección del flujo (hacia +Z) y vector transversal, en el plano XZ.
function tangenteRio(z) {
    const l = Math.hypot(rioDX(z), 1);
    return [rioDX(z) / l, 1 / l];
}

function distanciaRio(x, z) {
    return Math.abs(x - rioX(z)) / Math.sqrt(1 + rioDX(z) * rioDX(z));
}

function alturaBase(x, z) {

    const d = distanciaRio(x, z);

    // Colinas suaves que solo crecen lejos del río.
    const colinas = (fbm2(x * 0.045 + 10, z * 0.045) - 0.30) * 6.0
                  + (fbm2(x * 0.13, z * 0.13 + 5) - 0.5) * 0.7;
    const lejos = suave(6, 18, d);
    let h = NIVEL_ORILLA + Math.max(colinas, -0.3) * lejos;

    // Colinas de los molinos de viento.
    for (const m of configViento) {
        const r2 = (x - m.x) * (x - m.x) + (z - m.z) * (z - m.z);
        h += 2.4 * Math.exp(-r2 / 70);
    }

    // Montañas en el borde del mapa (no cierran la salida del río).
    const r = Math.hypot(x, z);
    const borde = suave(32, 54, r);
    h += borde * borde * 11.0 * suave(5, 16, d);

    return h;
}

// Altura en el centro de cada colina de viento (para aplanar la cima).
const alturaCimas = configViento.map(m => alturaBase(m.x, m.z));

function alturaTerreno(x, z) {

    let h = alturaBase(x, z);

    // Plataformas planas bajo cada molino de viento.
    configViento.forEach((m, i) => {
        const r = Math.hypot(x - m.x, z - m.z);
        const w = 1 - suave(3.0, 6.0, r);
        h = mezclar(h, alturaCimas[i], w);
    });

    // Cauce del río con fondo plano y orillas suaves.
    const d = distanciaRio(x, z);
    const lecho = -1.1 + (fbm2(x * 0.5, z * 0.5) - 0.5) * 0.25;
    const c = 1 - suave(2.0, 3.8, d);

    return mezclar(h, lecho, c);
}

// ------------------------------------------------------------
// Malla del terreno: vértice = pos(3) normal(3) uv(2) mezcla(2)
// mezcla.x = peso de arena/barro, mezcla.y = peso de roca
// ------------------------------------------------------------


export { NIVEL_AGUA, NIVEL_ORILLA, MEDIO_TERRENO, ANCHO_AGUA, configViento, configAgua, DIST_MOLINO_AGUA, rioX, rioDX, tangenteRio, distanciaRio, alturaBase, alturaCimas, alturaTerreno };
