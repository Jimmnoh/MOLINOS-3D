import { identidad4, multiplicarMat4, traslacion, escala, rotacionX, rotacionY, rotacionZ, componer, restar, normalizar, cruz, lookAt, perspectiva, ortografica } from "../math/Matrix4.js";
import { obtenerFaseLunar, calcularIluminacion } from '../scene/environment.js';
import { limitar, mezclar, suave, mezclarVec, crearRandom, hash2, ruido2, fbm2 } from "../utils/helpers.js";
import { NIVEL_AGUA, NIVEL_ORILLA, MEDIO_TERRENO, ANCHO_AGUA, configViento, configAgua, DIST_MOLINO_AGUA, rioX, rioDX, tangenteRio, distanciaRio, alturaBase, alturaCimas, alturaTerreno } from "../scene/terrain.js";
export function createControls(canvas,ambiente,molinosViento,molinosAgua,camera) {
const camara = {
    modo: "orbital",

    // Órbita alrededor de un objetivo (modos orbital, molino y recorrido)
    objetivo: [0, 2.5, 0],        // hacia dónde queremos mirar
    target: [0, 2.5, 0],          // valor suavizado que usa la vista
    distanciaObj: 48,
    distancia: 48,
    azimut: 0.55,
    elevacion: 0.42,
    distanciaMin: 4,
    distanciaMax: 90,

    // Vuelo libre
    pos: [0, 12, 45],
    yaw: 0,
    pitch: -0.2,

    molinoIdx: 0,
    sensibilidadMouse: 0.006,
    sensibilidadZoom: 0.0014
};

// Lista de molinos que se pueden "seguir" con la cámara.
const objetivosMolino = [];

molinosViento.forEach((m, i) => {
    objetivosMolino.push({
        nombre: "Molino de viento " + (i + 1) + "/" + molinosViento.length,
        pos: [m.cfg.x, alturaTerreno(m.cfg.x, m.cfg.z) + 3.8 * m.cfg.esc, m.cfg.z],
        dist: 15 * m.cfg.esc
    });
});

molinosAgua.forEach((m, i) => {
    objetivosMolino.push({
        nombre: "Molino hidráulico " + (i + 1) + "/" + molinosAgua.length,
        pos: [m.raiz.base[12], 1.6, m.raiz.base[14]],
        dist: 11 * m.cfg.esc
    });
});

const LIMITE_VERTICAL = Math.PI / 2 - 0.05;

function direccionVista() {
    // Vector hacia adelante en el modo libre (yaw/pitch).
    return [
        -Math.sin(camara.yaw) * Math.cos(camara.pitch),
        Math.sin(camara.pitch),
        -Math.cos(camara.yaw) * Math.cos(camara.pitch)
    ];
}

function obtenerEye() {

    if (camara.modo === "libre") {
        return camara.pos.slice();
    }

    const ce = Math.cos(camara.elevacion);

    return [
        camara.target[0] + camara.distancia * ce * Math.sin(camara.azimut),
        camara.target[1] + camara.distancia * Math.sin(camara.elevacion),
        camara.target[2] + camara.distancia * ce * Math.cos(camara.azimut)
    ];
}

function obtenerView() {

    const eye = obtenerEye();

    // La cámara nunca atraviesa el suelo.
    if (Math.abs(eye[0]) < MEDIO_TERRENO && Math.abs(eye[2]) < MEDIO_TERRENO) {
        eye[1] = Math.max(eye[1], alturaTerreno(eye[0], eye[2]) + 1.0);
    }

    if (camara.modo === "libre") {
        const f = direccionVista();
        camara.pos = eye;
        return { view: lookAt(eye, [eye[0] + f[0], eye[1] + f[1], eye[2] + f[2]], [0, 1, 0]), eye };
    }

    return { view: lookAt(eye, camara.target, [0, 1, 0]), eye };
}

function cambiarModoCamara(modo) {

    if (modo === camara.modo) return;

    const eye = obtenerEye();

    if (modo === "libre") {
        // Parte desde donde estaba la vista orbital.
        const f = normalizar(restar(camara.target, eye));
        camara.pos = eye;
        camara.yaw = Math.atan2(-f[0], -f[2]);
        camara.pitch = Math.asin(f[1]);
    } else if (camara.modo === "libre") {
        // Vuelve a órbita mirando 30 unidades por delante.
        const f = direccionVista();
        camara.objetivo = [eye[0] + f[0] * 30, Math.max(eye[1] + f[1] * 30, 1.0), eye[2] + f[2] * 30];
        camara.target = camara.objetivo.slice();
        camara.distancia = camara.distanciaObj = 30;
        camara.azimut = Math.atan2(-f[0], -f[2]);
        camara.elevacion = limitar(Math.asin(-f[1]), -LIMITE_VERTICAL, LIMITE_VERTICAL);
    }

    camara.modo = modo;

    if (modo === "molino") seleccionarMolino(camara.molinoIdx);

    const sel = document.getElementById("modoCam");
    if (sel) sel.value = modo;
}

function seleccionarMolino(i) {

    camara.molinoIdx = (i + objetivosMolino.length) % objetivosMolino.length;
    const o = objetivosMolino[camara.molinoIdx];

    camara.objetivo = o.pos.slice();
    camara.distanciaObj = o.dist;
    camara.elevacion = 0.25;

    const et = document.getElementById("molinoActual");
    if (et) et.textContent = o.nombre;
}

function reiniciarCamara() {

    camara.modo = "orbital";
    camara.objetivo = [0, 2.5, 0];
    camara.distanciaObj = 48;
    camara.azimut = 0.55;
    camara.elevacion = 0.42;

    const sel = document.getElementById("modoCam");
    if (sel) sel.value = "orbital";
}

// Mueve el punto que se mira sobre el plano del suelo.
function panear(derecha, adelante) {

    const s = Math.sin(camara.azimut), c = Math.cos(camara.azimut);
    // derecha = (cos az, 0, -sin az); adelante (hacia el objetivo) = (-sin az, 0, -cos az)
    camara.objetivo[0] += derecha * c + adelante * (-s);
    camara.objetivo[2] += derecha * (-s) + adelante * (-c);
    camara.objetivo[0] = limitar(camara.objetivo[0], -45, 45);
    camara.objetivo[2] = limitar(camara.objetivo[2], -45, 45);
}

// ============================================================
// 17. ENTRADA: MOUSE, TÁCTIL Y TECLADO
// ============================================================

const punteros = new Map();
let distanciaPellizco = 0;

canvas.addEventListener("contextmenu", e => e.preventDefault());

canvas.addEventListener("pointerdown", (e) => {

    canvas.setPointerCapture(e.pointerId);
    punteros.set(e.pointerId, { x: e.clientX, y: e.clientY, boton: e.button, shift: e.shiftKey });
    canvas.classList.add("arrastrando");

    if (punteros.size === 2) {
        const [a, b] = [...punteros.values()];
        distanciaPellizco = Math.hypot(a.x - b.x, a.y - b.y);
    }

    // Tocar la pantalla durante el recorrido devuelve el control al usuario.
    if (camara.modo === "recorrido") cambiarModoCamara("orbital");
});

function soltarPuntero(e) {
    punteros.delete(e.pointerId);
    if (punteros.size === 0) canvas.classList.remove("arrastrando");
}

canvas.addEventListener("pointerup", soltarPuntero);
canvas.addEventListener("pointercancel", soltarPuntero);

canvas.addEventListener("pointermove", (e) => {

    const p = punteros.get(e.pointerId);
    if (!p) return;

    const dx = e.clientX - p.x;
    const dy = e.clientY - p.y;
    p.x = e.clientX;
    p.y = e.clientY;

    // Pellizco con dos dedos: zoom
    if (punteros.size === 2) {
        const [a, b] = [...punteros.values()];
        const d = Math.hypot(a.x - b.x, a.y - b.y);
        camara.distanciaObj *= distanciaPellizco / Math.max(d, 1);
        distanciaPellizco = d;
        return;
    }

    const paneo = p.boton === 2 || p.boton === 1 || e.shiftKey;

    if (camara.modo === "libre") {
        camara.yaw -= dx * camara.sensibilidadMouse;
        camara.pitch = limitar(camara.pitch - dy * camara.sensibilidadMouse, -1.5, 1.5);
        return;
    }

    if (paneo) {
        if (camara.modo === "molino") cambiarModoCamara("orbital");
        const k = camara.distancia * 0.0016;
        panear(-dx * k, dy * k);
    } else {
        camara.azimut -= dx * camara.sensibilidadMouse;
        camara.elevacion = limitar(camara.elevacion + dy * camara.sensibilidadMouse,
            -0.2, LIMITE_VERTICAL);
    }
});

canvas.addEventListener("wheel", (e) => {

    e.preventDefault();

    if (camara.modo === "libre") {
        const f = direccionVista();
        const paso = -e.deltaY * 0.02;
        camara.pos = [camara.pos[0] + f[0] * paso, camara.pos[1] + f[1] * paso, camara.pos[2] + f[2] * paso];
        return;
    }

    camara.distanciaObj *= Math.exp(e.deltaY * camara.sensibilidadZoom);

}, { passive: false });

const teclas = new Set();
let pausa = false;

window.addEventListener("keydown", (e) => {

    if (e.target && (e.target.tagName === "INPUT" || e.target.tagName === "SELECT")) return;

    const k = e.key.toLowerCase();
    teclas.add(k);

    const paso = 0.08;

    switch (e.key) {
        case "ArrowLeft":  camara.azimut += paso; camara.yaw += paso; e.preventDefault(); break;
        case "ArrowRight": camara.azimut -= paso; camara.yaw -= paso; e.preventDefault(); break;
        case "ArrowUp":    camara.elevacion += paso; camara.pitch += paso; e.preventDefault(); break;
        case "ArrowDown":  camara.elevacion -= paso; camara.pitch -= paso; e.preventDefault(); break;
        case "+": case "=": camara.distanciaObj -= 3; break;
        case "-": case "_": camara.distanciaObj += 3; break;
        case " ": pausa = !pausa; e.preventDefault(); break;
        case "Tab":
            e.preventDefault();
            if (camara.modo !== "molino") cambiarModoCamara("molino");
            else seleccionarMolino(camara.molinoIdx + (e.shiftKey ? -1 : 1));
            break;
    }

    switch (k) {
        case "1": cambiarModoCamara("orbital"); break;
        case "2": cambiarModoCamara("libre"); break;
        case "3": cambiarModoCamara("molino"); break;
        case "4": cambiarModoCamara("recorrido"); break;
        case "r": reiniciarCamara(); break;
        case "v": ambiente.viento = limitar(ambiente.viento + (e.shiftKey ? -0.2 : 0.2), 0, 4); sincronizarPanel(); break;
        case "c": ambiente.caudal = limitar(ambiente.caudal + (e.shiftKey ? -0.2 : 0.2), 0, 3); sincronizarPanel(); break;
        case "t": ambiente.cicloAuto = !ambiente.cicloAuto; sincronizarPanel(); break;
        case "m": ambiente.sombras = !ambiente.sombras; sincronizarPanel(); break;
    }

    camara.elevacion = limitar(camara.elevacion, -0.2, LIMITE_VERTICAL);
    camara.pitch = limitar(camara.pitch, -1.5, 1.5);
    camara.distanciaObj = limitar(camara.distanciaObj, camara.distanciaMin, camara.distanciaMax);
});

window.addEventListener("keyup", (e) => teclas.delete(e.key.toLowerCase()));
window.addEventListener("blur", () => teclas.clear());

// Teclas mantenidas: WASD (+ Q/E en vuelo libre).
function procesarTeclasContinuas(dt) {

    const turbo = teclas.has("shift") ? 3 : 1;

    if (camara.modo === "libre") {

        const v = 14 * turbo * dt;
        const f = direccionVista();
        const der = [Math.cos(camara.yaw), 0, -Math.sin(camara.yaw)];
        const m = [0, 0, 0];

        if (teclas.has("w")) { m[0] += f[0]; m[1] += f[1]; m[2] += f[2]; }
        if (teclas.has("s")) { m[0] -= f[0]; m[1] -= f[1]; m[2] -= f[2]; }
        if (teclas.has("d")) { m[0] += der[0]; m[2] += der[2]; }
        if (teclas.has("a")) { m[0] -= der[0]; m[2] -= der[2]; }
        if (teclas.has("e")) m[1] += 1;
        if (teclas.has("q")) m[1] -= 1;

        camara.pos = [camara.pos[0] + m[0] * v, camara.pos[1] + m[1] * v, camara.pos[2] + m[2] * v];
        camara.pos[1] = limitar(camara.pos[1], 0.5, 70);

    } else if (camara.modo === "orbital") {

        const v = camara.distancia * 0.8 * turbo * dt;
        const adelante = (teclas.has("w") ? 1 : 0) - (teclas.has("s") ? 1 : 0);
        const derecha = (teclas.has("d") ? 1 : 0) - (teclas.has("a") ? 1 : 0);

        if (adelante || derecha) panear(derecha * v * 0.5, adelante * v * 0.5);
    }
}

const $ = (id) => document.getElementById(id);

function sincronizarPanel() {

    if ($("viento")) $("viento").value = ambiente.viento;
    if ($("caudal")) $("caudal").value = ambiente.caudal;
    if ($("hora")) $("hora").value = ambiente.hora;
    if ($("ciclo")) $("ciclo").checked = ambiente.cicloAuto;
    if ($("sombras")) $("sombras").checked = ambiente.sombras;
    if ($("faseLunar")) $("faseLunar").value=ambiente.diaLunar;
    if ($("brilloLunar")) $("brilloLunar").value=ambiente.brilloLunar;
    if ($("fasesAuto")) $("fasesAuto").checked=ambiente.fasesAuto;
    actualizarEtiquetas();
}

function actualizarEtiquetas() {
    const lunar=obtenerFaseLunar(ambiente.diaLunar);
    if($("faseVal")) $("faseVal").textContent=lunar.nombre+' · '+Math.round(lunar.iluminada*100)+'%';
    if($("bLVal")) $("bLVal").textContent=ambiente.brilloLunar.toFixed(1)+'×';
    if($("faseLunar")) $("faseLunar").value=ambiente.diaLunar;

    if ($("vVal")) $("vVal").textContent = ambiente.viento.toFixed(1);
    if ($("cVal")) $("cVal").textContent = ambiente.caudal.toFixed(1);

    if ($("hVal")) {
        const h = Math.floor(ambiente.hora) % 24;
        const m = Math.floor((ambiente.hora % 1) * 60);
        $("hVal").textContent = String(h).padStart(2, "0") + ":" + String(m).padStart(2, "0");
    }
}

function enlazarPanel() {
    if($("faseLunar")) $("faseLunar").addEventListener('input',event=>{
        ambiente.diaLunar=parseFloat(event.target.value);
        ambiente.fasesAuto=false;
        if($("fasesAuto")) $("fasesAuto").checked=false;
        actualizarEtiquetas();
    });
    if($("brilloLunar")) $("brilloLunar").addEventListener('input',event=>{
        ambiente.brilloLunar=parseFloat(event.target.value);actualizarEtiquetas();
    });
    if($("fasesAuto")) $("fasesAuto").addEventListener('change',event=>{ambiente.fasesAuto=event.target.checked;});
    if($("btnNoche")) $("btnNoche").addEventListener('click',()=>{
        ambiente.hora=19.5; ambiente.cicloAuto=false;
        const luna=calcularIluminacion().luna;
        reiniciarCamara();
        camara.azimut=Math.atan2(-luna[0],-luna[2]);
        camara.elevacion=0.02;
        sincronizarPanel();
    });

    if ($("viento")) $("viento").addEventListener("input", e => { ambiente.viento = parseFloat(e.target.value); actualizarEtiquetas(); });
    if ($("caudal")) $("caudal").addEventListener("input", e => { ambiente.caudal = parseFloat(e.target.value); actualizarEtiquetas(); });
    if ($("hora")) $("hora").addEventListener("input", e => { ambiente.hora = parseFloat(e.target.value); ambiente.cicloAuto = false; sincronizarPanel(); });
    if ($("ciclo")) $("ciclo").addEventListener("change", e => { ambiente.cicloAuto = e.target.checked; });
    if ($("sombras")) $("sombras").addEventListener("change", e => { ambiente.sombras = e.target.checked; });
    if ($("modoCam")) $("modoCam").addEventListener("change", e => { cambiarModoCamara(e.target.value); e.target.blur(); });
    if ($("btnSiguiente")) $("btnSiguiente").addEventListener("click", () => {
        if (camara.modo !== "molino") cambiarModoCamara("molino");
        else seleccionarMolino(camara.molinoIdx + 1);
    });
    if ($("btnReset")) $("btnReset").addEventListener("click", reiniciarCamara);
    if ($("btnPausa")) $("btnPausa").addEventListener("click", () => { pausa = !pausa; });
}

enlazarPanel();
sincronizarPanel();

function actualizarCamara(dt, t) {

    if (camara.modo === "recorrido") {
        camara.azimut += dt * 0.10;
        camara.elevacion = 0.30 + 0.12 * Math.sin(t * 0.10);
        camara.distanciaObj = 40 + 10 * Math.sin(t * 0.07);
        const z = 28 * Math.sin(t * 0.045);
        camara.objetivo = [rioX(z) * 0.6, 3.0, z];
    }

    camara.distanciaObj = limitar(camara.distanciaObj, camara.distanciaMin, camara.distanciaMax);

    // Suavizado exponencial: el movimiento no se siente brusco.
    const k = 1 - Math.exp(-dt * 6);
    for (let i = 0; i < 3; i++) {
        camara.target[i] += (camara.objetivo[i] - camara.target[i]) * k;
    }
    camara.distancia += (camara.distanciaObj - camara.distancia) * k;

    procesarTeclasContinuas(dt);
}


return {
    get paused() { return pausa; },
    actualizarEtiquetas,
    update(dt,t) {
        actualizarCamara(dt,t);
        const {view,eye}=obtenerView();
        camera.position={x:eye[0],y:eye[1],z:eye[2]};
        const f=camara.modo==='libre' ? direccionVista() : restar(camara.target,eye);
        camera.target=[eye[0]+f[0],eye[1]+f[1],eye[2]+f[2]];
    }
};
}
