export class Geometry {
    constructor(data = {}, attributes = [3,3,2]) {
        this.vertices = data.vertices || new Float32Array();
        this.indices = data.indices || new Uint16Array();
        this.attributes = attributes;
        this.indexCount = this.indices.length;
        this.initialized = false;
        this.vao = this.vbo = this.ebo = null;
    }
}
