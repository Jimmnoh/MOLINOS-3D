import { InstanceBatch } from "./InstanceBatch.js";
import { identidad4, multiplicarMat4, traslacion, escala, rotacionX, rotacionY, rotacionZ, componer, restar, normalizar, cruz, lookAt, perspectiva, ortografica } from "../math/Matrix4.js";
import { limitar, mezclar, suave, mezclarVec, crearRandom, hash2, ruido2, fbm2 } from "../utils/helpers.js";
import { calcularIluminacion } from '../scene/environment.js';
import { SOMBRA_TAM,objetoVS,objetoFS,terrenoVS,terrenoFS,aguaVS,aguaFS,cieloVS,cieloFS,sombraVS,sombraFS } from '../materials/shaders.js';
export class Renderer {
constructor(canvas) {
const gl=canvas.getContext('webgl2',{antialias:true});
if(!gl) throw new Error('WebGL2 no está disponible.');
this.gl=gl; this.canvas=canvas;
gl.enable(gl.DEPTH_TEST); gl.enable(gl.CULL_FACE); gl.cullFace(gl.BACK);
gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL,true);
let mallas,tex,molinosAgua,ambiente,proyeccion,aspecto;
let quality=1;
let dibujablesEstaticos=[],dibujablesDinamicos=[];
const batches=new Map();
const resourceIds=new Map();
let nextResourceId=0;
const resourceId=resource=>{
    if(!resourceIds.has(resource)) resourceIds.set(resource,++nextResourceId);
    return resourceIds.get(resource);
};
function updateBatches(meshes) {
    for(const batch of batches.values()) batch.meshes.length=0;
    for(const mesh of meshes) {
        const key=resourceId(mesh.geometry)+':'+resourceId(mesh.material.texture)+':'+Number(mesh.castShadow);
        if(!batches.has(key)) batches.set(key,new InstanceBatch(gl,mesh.geometry,mesh.material.texture,mesh.castShadow));
        batches.get(key).meshes.push(mesh);
    }
    for(const [key,batch] of batches) {
        if(batch.meshes.length) batch.upload();
        else {batch.dispose();batches.delete(key);}
    }
}
const salp = new Float32Array(32);
function crearMalla(geo, capas) {

    if (geo.initialized) return geo;
    capas = geo.attributes;
    const vao = gl.createVertexArray();
    gl.bindVertexArray(vao);

    const vbo = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, vbo);
    gl.bufferData(gl.ARRAY_BUFFER, geo.vertices, gl.STATIC_DRAW);

    const ebo = gl.createBuffer();
    gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, ebo);
    gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, geo.indices, gl.STATIC_DRAW);

    const total = capas.reduce((a, b) => a + b, 0);
    const stride = total * Float32Array.BYTES_PER_ELEMENT;
    let offset = 0;

    capas.forEach((tam, loc) => {
        gl.enableVertexAttribArray(loc);
        gl.vertexAttribPointer(loc, tam, gl.FLOAT, false, stride,
            offset * Float32Array.BYTES_PER_ELEMENT);
        offset += tam;
    });

    gl.bindVertexArray(null);

    Object.assign(geo,{vao,vbo,ebo,cantidad:geo.indexCount,tipo:geo.indices instanceof Uint32Array ? gl.UNSIGNED_INT : gl.UNSIGNED_SHORT,initialized:true});
return geo;
}

function crearShader(tipo, fuente) {

    const shader = gl.createShader(tipo);
    gl.shaderSource(shader, fuente);
    gl.compileShader(shader);

    if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) {
        const log = gl.getShaderInfoLog(shader);
        console.error(fuente.split("\n").map((l, i) => (i + 1) + ": " + l).join("\n"));
        throw new Error(log);
    }

    return shader;
}

function crearPrograma(vertexSource, fragmentSource) {

    const programa = gl.createProgram();
    gl.attachShader(programa, crearShader(gl.VERTEX_SHADER, vertexSource));
    gl.attachShader(programa, crearShader(gl.FRAGMENT_SHADER, fragmentSource));
    gl.linkProgram(programa);

    if (!gl.getProgramParameter(programa, gl.LINK_STATUS)) {
        throw new Error(gl.getProgramInfoLog(programa));
    }

    return programa;
}

function ubicaciones(programa, nombres) {
    const r = {};
    nombres.forEach(n => { r[n] = gl.getUniformLocation(programa, n); });
    return r;
}

const UNIFORMS_COMUNES = [
    "uSunDir", "uLightDir", "uMoonDir", "uMoonPhase", "uMoonBrightness", "uSunColor", "uAmbSky", "uAmbGround", "uCamPos", "uNoche", "uDia",
    "uFogDensity", "uSombraFuerza", "uQuality", "uLightVP", "uShadowMap", "uView", "uProj"
];

const progObjeto = crearPrograma(objetoVS, objetoFS);
const progTerreno = crearPrograma(terrenoVS, terrenoFS);
const progAgua = crearPrograma(aguaVS, aguaFS);
const progCielo = crearPrograma(cieloVS, cieloFS);
const progSombra = crearPrograma(sombraVS, sombraFS);

const locObjeto = ubicaciones(progObjeto, UNIFORMS_COMUNES.concat(
    ["uModel", "uTexture", "uColor", "uUvEsc", "uBrillo", "uEmisivo"]));
const locTerreno = ubicaciones(progTerreno, UNIFORMS_COMUNES.concat(
    ["uPasto", "uTierra", "uRoca"]));
const locAgua = ubicaciones(progAgua, UNIFORMS_COMUNES.concat(
    ["uNormalMap", "uEspuma", "uFlowTime", "uSalp", "uNumSalp"]));
const locCielo = ubicaciones(progCielo, UNIFORMS_COMUNES.concat(
    ["uRight", "uUp", "uFwd", "uTan", "uAspect", "uTime"]));
const locSombra = ubicaciones(progSombra, ["uModel", "uLightVP", "uInstanced"]);

const texSombra = gl.createTexture();
gl.bindTexture(gl.TEXTURE_2D, texSombra);
gl.texStorage2D(gl.TEXTURE_2D, 1, gl.DEPTH_COMPONENT24, SOMBRA_TAM, SOMBRA_TAM);
gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_COMPARE_MODE, gl.COMPARE_REF_TO_TEXTURE);
gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_COMPARE_FUNC, gl.LEQUAL);

const fboSombra = gl.createFramebuffer();
gl.bindFramebuffer(gl.FRAMEBUFFER, fboSombra);
gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.DEPTH_ATTACHMENT, gl.TEXTURE_2D, texSombra, 0);
gl.drawBuffers([gl.NONE]);
gl.readBuffer(gl.NONE);
gl.bindFramebuffer(gl.FRAMEBUFFER, null);

// Samplers: cada programa debe tener un sampler distinto por unidad de textura.
gl.useProgram(progObjeto);
gl.uniform1i(locObjeto.uTexture, 0);
gl.uniform1i(locObjeto.uShadowMap, 3);

gl.useProgram(progTerreno);
gl.uniform1i(locTerreno.uPasto, 0);
gl.uniform1i(locTerreno.uTierra, 1);
gl.uniform1i(locTerreno.uRoca, 2);
gl.uniform1i(locTerreno.uShadowMap, 3);

gl.useProgram(progAgua);
gl.uniform1i(locAgua.uNormalMap, 4);
gl.uniform1i(locAgua.uEspuma, 5);
gl.uniform1i(locAgua.uShadowMap, 3);

gl.useProgram(progCielo);
gl.uniform1i(locCielo.uShadowMap, 3);

function subirComunes(loc, luzInfo, view, eye, lightVP, sombraFuerza) {

    gl.uniformMatrix4fv(loc.uView, false, view);
    gl.uniformMatrix4fv(loc.uProj, false, proyeccion);
    gl.uniformMatrix4fv(loc.uLightVP, false, lightVP);

    gl.uniform3fv(loc.uSunDir, luzInfo.sol);
    gl.uniform3fv(loc.uLightDir, luzInfo.luz);
    gl.uniform3fv(loc.uMoonDir, luzInfo.luna);
    gl.uniform1f(loc.uMoonPhase,luzInfo.faseLunar);
    gl.uniform1f(loc.uMoonBrightness,luzInfo.brilloLunar);
    gl.uniform3fv(loc.uSunColor, luzInfo.colorLuz);
    gl.uniform3fv(loc.uAmbSky, luzInfo.ambCielo);
    gl.uniform3fv(loc.uAmbGround, luzInfo.ambSuelo);
    gl.uniform3fv(loc.uCamPos, eye);
    gl.uniform1f(loc.uNoche, luzInfo.noche);
    gl.uniform1f(loc.uDia, luzInfo.dia);
    gl.uniform1f(loc.uFogDensity, 0.0075);
    gl.uniform1f(loc.uSombraFuerza, sombraFuerza);
    gl.uniform1f(loc.uQuality,quality);
}

// ============================================================
// 20. FUNCIONES DE DIBUJO
// ============================================================

function dibujarMalla(malla) {
    gl.bindVertexArray(malla.vao);
    gl.drawElements(gl.TRIANGLES, malla.cantidad, malla.tipo, 0);
}

function dibujarObjetos() {
    gl.activeTexture(gl.TEXTURE0);
    for(const batch of batches.values()) {
        gl.bindTexture(gl.TEXTURE_2D,batch.texture);
        batch.draw();
    }
}

function pasadaSombras(lightVP) {

    gl.bindFramebuffer(gl.FRAMEBUFFER, fboSombra);
    gl.viewport(0, 0, SOMBRA_TAM, SOMBRA_TAM);
    gl.clear(gl.DEPTH_BUFFER_BIT);

    gl.enable(gl.POLYGON_OFFSET_FILL);
    gl.polygonOffset(1.5, 3.0);

    gl.useProgram(progSombra);
    gl.uniformMatrix4fv(locSombra.uLightVP, false, lightVP);

    gl.uniform1i(locSombra.uInstanced,0);
    gl.uniformMatrix4fv(locSombra.uModel, false, identidad4());
    dibujarMalla(mallas.terreno);

    gl.uniform1i(locSombra.uInstanced,1);
    for(const batch of batches.values()) if(batch.castShadow) batch.draw();

    gl.disable(gl.POLYGON_OFFSET_FILL);
    gl.bindFramebuffer(gl.FRAMEBUFFER, null);
}


this.render=(scene,camera,{time=0,simulationTime=0,environment}={})=> {
    ambiente=environment; mallas=scene.mallas; tex=scene.textures; molinosAgua=scene.molinosAgua;
    // Evitar cuadruplicar los pixeles en pantallas de alta densidad.
    quality=ambiente.quality==='rapida' ? 0 : ambiente.quality==='alta' ? 2 : 1;
    const pixelBudget=quality===0 ? 650000 : quality===1 ? 1000000 : 1500000;
    const dpr=Math.min(window.devicePixelRatio || 1,1,Math.sqrt(pixelBudget/Math.max(1,canvas.clientWidth*canvas.clientHeight)));
    const w=Math.max(1,Math.floor(canvas.clientWidth*dpr)), h=Math.max(1,Math.floor(canvas.clientHeight*dpr));
    if(canvas.width!==w || canvas.height!==h) {canvas.width=w; canvas.height=h;}
    aspecto=w/h;
    if(camera.aspect!==aspecto || camera.fov!==camera._lastFov || camera.near!==camera._lastNear || camera.far!==camera._lastFar) {
        camera.aspect=aspecto; camera.updateProjectionMatrix();
        camera._lastFov=camera.fov; camera._lastNear=camera.near; camera._lastFar=camera.far;
    }
    camera.updateMatrixWorld(camera.parent ? camera.parent.matrixWorld : null); camera.updateViewMatrix(); proyeccion=camera.projectionMatrix;
    scene.updateMatrixWorld(null,simulationTime);
    dibujablesEstaticos.length=0; dibujablesDinamicos.length=0;
    const collect=node=> { if(!node.visible) return; if(node.geometry && node.material) dibujablesEstaticos.push(node); for(const child of node.children) collect(child); };
    collect(scene);
    for(const geo of Object.values(mallas)) crearMalla(geo,geo.attributes);
    for(const mesh of dibujablesEstaticos) crearMalla(mesh.geometry,mesh.geometry.attributes);
    updateBatches(dibujablesEstaticos);
    this.stats={meshes:dibujablesEstaticos.length,batches:batches.size};
    const t=time;
    // --- Iluminación y matrices de la luz
    const luzInfo = calcularIluminacion();
    const sombraFuerza = ambiente.sombras ? suave(0.03, 0.15, luzInfo.luz[1]) : 0;

    const luzEye = [luzInfo.luz[0] * 70, luzInfo.luz[1] * 70, luzInfo.luz[2] * 70];
    const lightVP = multiplicarMat4(
        ortografica(-52, 52, -52, 52, 5, 150),
        lookAt(luzEye, [0, 0, 0], [0, 1, 0])
    );

    // --- Pasada 1: mapa de sombras
    if (sombraFuerza > 0) {
        pasadaSombras(lightVP);
    }

    // --- Pasada 2: escena
    const view=camera.viewMatrix, eye=camera.eye;

    gl.viewport(0, 0, canvas.width, canvas.height);
    gl.clearColor(0, 0, 0, 1);
    gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);

    gl.activeTexture(gl.TEXTURE3);
    gl.bindTexture(gl.TEXTURE_2D, texSombra);

    // Cielo (sin profundidad)
    gl.disable(gl.DEPTH_TEST);
    gl.disable(gl.CULL_FACE);

    gl.useProgram(progCielo);
    subirComunes(locCielo, luzInfo, view, eye, lightVP, sombraFuerza);
    gl.uniform3f(locCielo.uRight, view[0], view[4], view[8]);
    gl.uniform3f(locCielo.uUp, view[1], view[5], view[9]);
    gl.uniform3f(locCielo.uFwd, -view[2], -view[6], -view[10]);
    gl.uniform1f(locCielo.uTan, Math.tan(camera.fov * Math.PI / 180 / 2));
    gl.uniform1f(locCielo.uAspect, aspecto);
    gl.uniform1f(locCielo.uTime, t);

    gl.bindVertexArray(null);
    gl.drawArrays(gl.TRIANGLES, 0, 3);

    gl.enable(gl.DEPTH_TEST);
    gl.enable(gl.CULL_FACE);

    // Terreno
    gl.useProgram(progTerreno);
    subirComunes(locTerreno, luzInfo, view, eye, lightVP, sombraFuerza);

    gl.activeTexture(gl.TEXTURE0); gl.bindTexture(gl.TEXTURE_2D, tex.pasto);
    gl.activeTexture(gl.TEXTURE1); gl.bindTexture(gl.TEXTURE_2D, tex.tierra);
    gl.activeTexture(gl.TEXTURE2); gl.bindTexture(gl.TEXTURE_2D, tex.roca);

    dibujarMalla(mallas.terreno);

    // Molinos, árboles, rocas, puente
    gl.useProgram(progObjeto);
    subirComunes(locObjeto, luzInfo, view, eye, lightVP, sombraFuerza);

    dibujarObjetos();

    // Agua (translúcida, al final)
    gl.useProgram(progAgua);
    subirComunes(locAgua, luzInfo, view, eye, lightVP, sombraFuerza);
    gl.uniform1f(locAgua.uFlowTime, ambiente.tiempoFlujo);

    salp.fill(0);
    molinosAgua.forEach((m, i) => {
        salp.set([m.salpicadura[0], m.salpicadura[1], m.salpicadura[2], 0], i * 4);
    });
    gl.uniform4fv(locAgua.uSalp, salp);
    gl.uniform1i(locAgua.uNumSalp, molinosAgua.length);

    gl.activeTexture(gl.TEXTURE4); gl.bindTexture(gl.TEXTURE_2D, tex.aguaNormal);
    gl.activeTexture(gl.TEXTURE5); gl.bindTexture(gl.TEXTURE_2D, tex.espuma);

    gl.enable(gl.BLEND);
    gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA);
    gl.depthMask(false);

    dibujarMalla(mallas.agua);

    gl.depthMask(true);
    gl.disable(gl.BLEND);


};
}
}
