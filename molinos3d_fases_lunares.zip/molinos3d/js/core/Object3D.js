import { Matrix4 } from '../math/Matrix4.js';
export class Object3D {
    constructor() {
        this.position={x:0,y:0,z:0}; this.rotation={x:0,y:0,z:0}; this.scale={x:1,y:1,z:1};
        this.parent=null; this.children=[]; this.visible=true;
        this.base=Matrix4.identidad(); this.anim=null;
        this.matrix=Matrix4.identidad(); this.matrixWorld=Matrix4.identidad();
        this._transform = new Float64Array(9).fill(NaN);
        this._base = new Float32Array(16).fill(NaN);
        this._parentMatrix = new Float32Array(16).fill(NaN);
        this._hadParent = false;
        this._worldReady = false;
    }
    add(child) {
        for(let p=this;p;p=p.parent) if(p===child) throw new Error('Jerarquía cíclica');
        if(child.parent) child.parent.remove(child);
        child.parent=this; this.children.push(child); return this;
    }
    remove(child) {
        const i=this.children.indexOf(child);
        if(i!==-1) { this.children.splice(i,1); child.parent=null; }
        return this;
    }
    updateMatrix(time=0) {
        const p=this.position, r=this.rotation, s=this.scale, prev=this._transform;
        let changed=p.x!==prev[0] || p.y!==prev[1] || p.z!==prev[2] ||
            r.x!==prev[3] || r.y!==prev[4] || r.z!==prev[5] ||
            s.x!==prev[6] || s.y!==prev[7] || s.z!==prev[8];
        for(let i=0;i<16;i++) if(this.base[i]!==this._base[i]) {changed=true;break;}
        // Los edificios y arboles no necesitan componer matrices cada cuadro.
        if(!changed && !this.anim && !this._wasAnimated) return false;
        prev[0]=p.x; prev[1]=p.y; prev[2]=p.z;
        prev[3]=r.x; prev[4]=r.y; prev[5]=r.z;
        prev[6]=s.x; prev[7]=s.y; prev[8]=s.z;
        this._base.set(this.base);
        this._wasAnimated=!!this.anim;
        // base conserva exactamente el orden de transformación original.
        if(p.x===0 && p.y===0 && p.z===0 && r.x===0 && r.y===0 && r.z===0 && s.x===1 && s.y===1 && s.z===1) {
            this.matrix.set(this.base);
        } else {
            this.matrix=Matrix4.multiplicar(this.base,Matrix4.compose(p,r,s));
        }
        if(this.anim) this.matrix=Matrix4.multiplicar(this.matrix,this.anim(time));
        return true;
    }
    updateMatrixWorld(parentMatrix=null,time=0) {
        const localChanged=this.updateMatrix(time);
        let parentChanged=!!parentMatrix!==this._hadParent;
        if(parentMatrix) {
            for(let i=0;i<16;i++) if(parentMatrix[i]!==this._parentMatrix[i]) {parentChanged=true;break;}
        }
        if(localChanged || parentChanged || !this._worldReady) {
            this.matrixWorld=parentMatrix ? Matrix4.multiplicar(parentMatrix,this.matrix) : new Float32Array(this.matrix);
            if(parentMatrix) this._parentMatrix.set(parentMatrix);
            this._hadParent=!!parentMatrix;
            this._worldReady=true;
        }
        for(const child of this.children) child.updateMatrixWorld(this.matrixWorld,time);
    }
    traverse(callback) { callback(this); for(const child of this.children) child.traverse(callback); }
}
