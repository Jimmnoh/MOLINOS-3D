// Agrupa piezas de la misma geometria/textura en una sola llamada WebGL2.
// La escena sigue formada por Mesh individuales, con sus propios materiales.
export class InstanceBatch {
    constructor(gl, geometry, texture, castShadow) {
        Object.assign(this,{gl,geometry,texture,castShadow});
        this.meshes=[];
        this.capacity=0;
        this.vao=gl.createVertexArray();
        this.buffer=gl.createBuffer();
        gl.bindVertexArray(this.vao);
        gl.bindBuffer(gl.ARRAY_BUFFER,geometry.vbo);
        const stride=geometry.attributes.reduce((a,b)=>a+b,0)*4;
        let offset=0;
        geometry.attributes.forEach((size,location)=>{
            gl.enableVertexAttribArray(location);
            gl.vertexAttribPointer(location,size,gl.FLOAT,false,stride,offset*4);
            offset+=size;
        });
        gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER,geometry.ebo);
        gl.bindBuffer(gl.ARRAY_BUFFER,this.buffer);
        // mat4 ocupa las ubicaciones 4, 5, 6 y 7.
        for(let col=0;col<4;col++) this.attribute(4+col,4,col*4);
        this.attribute(8,4,16); // color RGB + emision
        this.attribute(9,3,20); // escala UV + brillo
        gl.bindVertexArray(null);
    }
    attribute(location,size,offset) {
        const gl=this.gl;
        gl.enableVertexAttribArray(location);
        gl.vertexAttribPointer(location,size,gl.FLOAT,false,23*4,offset*4);
        gl.vertexAttribDivisor(location,1);
    }
    upload() {
        const gl=this.gl, count=this.meshes.length;
        gl.bindBuffer(gl.ARRAY_BUFFER,this.buffer);
        if(count>this.capacity) {
            this.capacity=Math.max(count,this.capacity*2,16);
            this.data=new Float32Array(this.capacity*23);
            gl.bufferData(gl.ARRAY_BUFFER,this.data.byteLength,gl.DYNAMIC_DRAW);
        }
        for(let i=0;i<count;i++) {
            const mesh=this.meshes[i],m=mesh.material,offset=i*23;
            this.data.set(mesh.matrixWorld,offset);
            this.data.set(m.color,offset+16);
            this.data[offset+19]=Number(m.emissive);
            this.data.set(m.uv,offset+20);
            this.data[offset+22]=m.brillo;
        }
        gl.bufferSubData(gl.ARRAY_BUFFER,0,this.data.subarray(0,count*23));
    }
    draw() {
        if(!this.meshes.length) return;
        const gl=this.gl,g=this.geometry;
        gl.bindVertexArray(this.vao);
        gl.drawElementsInstanced(gl.TRIANGLES,g.cantidad,g.tipo,0,this.meshes.length);
    }
    dispose() {
        this.gl.deleteBuffer(this.buffer);
        this.gl.deleteVertexArray(this.vao);
    }
}
